# Abacus.AI Skill Format — Detaljna referenca

## Pregled

Abacus.AI Agent Skill je .zip paket koji sadrži SKILL.md fajl na root nivou i opcione prateće foldere.

## Struktura .zip paketa

```
skill-name.zip
├── SKILL.md          # OBAVEZAN — na root nivou
├── examples/         # Opciono — primeri korišćenja
├── templates/        # Opciono — šabloni za izlaz
├── references/       # Opciono — detaljne reference
└── scripts/          # Opciono — pomoćne skripte
```

### Kritična pravila:
- SKILL.md MORA biti direktno u root-u .zip fajla, NE u podfolderu
- ✅ Ispravno: `skill.zip/SKILL.md`
- ❌ Neispravno: `skill.zip/folder/SKILL.md`
- Maksimalna veličina: 50MB
- Format: samo .zip

## SKILL.md struktura

### 1. Opis skill-a (vrh fajla)
Prvi pasus definiše ulogu AI-ja i kontekst aktivacije.

### 2. Opis aktivacije
Koji tipovi zahteva aktiviraju skill. Ključne reči za prepoznavanje.
Maksimalno 1024 karaktera za opis u Abacus.AI interfejsu.

### 3. Workflow
Korak-po-korak uputstva za izvršavanje zadataka.
Minimum 3 koraka sa konkretnim instrukcijama.

### 4. Alati i mogućnosti
Koji DeepAgent alati su potrebni (web pretraga, kod, fajlovi, itd.)

### 5. Standardi kvaliteta
Pravila za format, jezik, tačnost i kompletnost izlaza.

### 6. Primeri
Minimum 2 primera sa ulazom i očekivanim izlazom.

## Pravila imenovanja

- Format: `lowercase-sa-crticama`
- Primeri: `tech-writer`, `data-analyst`, `code-reviewer`
- Bez razmaka, specijalnih karaktera ili velikih slova
- Kratko i opisno (2-4 reči)

## Upravljanje skill-ovima

### Aktivacija
- Skill se aktivira automatski kada je uključen i kada zahtev korisnika odgovara opisu
- Preporuka: 5-10 aktivnih skill-ova za optimalne performanse

### Gde rade skill-ovi
- Abacus AI Agent mod
- Projekti sa aktiviranim Agent-om

### Ažuriranje
1. Preuzmi postojeći .zip
2. Izmeni SKILL.md i prateće fajlove
3. Ponovo otpremi .zip
4. Dodaj sufiks verzije (_v2, _v3) za praćenje promena

## Česte greške

| Problem | Uzrok | Rešenje |
|---------|-------|---------|
| Skill se ne aktivira | Opis ne pokriva zahtev | Proširi opis sa više ključnih reči |
| Upload neuspešan | .zip > 50MB | Kompresuj sadržaj |
| Nevažeći paket | SKILL.md nije na root-u | Proveri strukturu .zip fajla |
| Duplikat naziva | Skill sa istim imenom postoji | Koristi jedinstven naziv ili obriši stari |
