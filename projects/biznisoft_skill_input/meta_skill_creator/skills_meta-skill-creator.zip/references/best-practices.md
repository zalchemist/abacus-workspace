# Best Practices za kreiranje skill-ova

## 1. Fokusirani skill-ovi

Jedan skill = jedan domen. Ne praviti "skill za sve".

**Dobro:**
- `tech-writer` — pisanje tehničke dokumentacije
- `csv-analyst` — analiza CSV fajlova
- `code-reviewer` — pregled koda

**Loše:**
- `svemogući-skill` — piše, analizira, pregleda, prevodi...

### Zašto?
- AI bolje razume specifične instrukcije
- Lakše održavanje i ažuriranje
- Korisnik bira koji skill mu treba
- Manja šansa za konflikte između skill-ova

## 2. Progresivno otkrivanje

Osnovno u SKILL.md, detalji u pratećim fajlovima.

```
SKILL.md (< 500 redova)
├── Osnovni workflow (korak po korak)
├── Ključna pravila
└── Kratki primeri

references/ (detalji)
├── Detaljne metodologije
├── Kompletne reference
└── Napredni scenariji

examples/ (konkretni primeri)
├── Kompletan ulaz → izlaz
└── Edge case scenariji
```

### Zašto?
- SKILL.md se učitava prvi — mora biti sažet
- AI može da konsultuje references/ po potrebi
- Smanjuje kognitivno opterećenje

## 3. Jasni opisi za aktivaciju

Opis skill-a je ključan za automatsku aktivaciju.

**Dobro:**
```
Ovaj skill se aktivira za pisanje tehničke dokumentacije, 
API dokumentacije, korisničkih uputstava i README fajlova. 
Prepoznaje zahteve: "napiši dokumentaciju", "dokumentuj API", 
"napravi README", "korisničko uputstvo".
```

**Loše:**
```
Skill za pisanje.
```

### Pravila za opis:
- Navedi konkretne tipove zahteva
- Uključi ključne reči koje korisnik koristi
- Navedi šta skill NE pokriva (da se izbegne pogrešna aktivacija)
- Maksimum 1024 karaktera

## 4. Konkretni primeri

Svaki primer mora biti realan i kompletan.

**Dobro:**
```markdown
### Primer: API dokumentacija
**Ulaz:** "Dokumentuj /users endpoint koji prima GET zahtev 
i vraća listu korisnika sa paginacijom."
**Izlaz:** 
## GET /users
Vraća paginiranu listu korisnika.
### Parametri
| Parametar | Tip | Obavezno | Opis |
|-----------|-----|----------|------|
| page | int | ne | Broj stranice (podrazumevano: 1) |
| limit | int | ne | Stavki po stranici (podrazumevano: 20) |
...
```

**Loše:**
```markdown
### Primer
Korisnik traži dokumentaciju. AI napiše dokumentaciju.
```

## 5. Verzioniranje

Dodaj sufiks verzije kod ažuriranja:
- `tech-writer_v1` → `tech-writer_v2`
- Ili drži CHANGELOG.md u skill paketu
- Zapisuj šta je promenjeno u svakoj verziji

## 6. Jezik i konzistentnost

- Izaberi jedan jezik za ceo skill (srpski ILI engleski)
- Srpski: uvek ekavica, latinica
- Tehnički termini mogu ostati na engleskom (workflow, skill, zip)
- Komande i kod uvek na engleskom

## 7. Testiranje pre isporuke

1. Proveri da li SKILL.md ima sve sekcije
2. Proveri da .zip ima ispravnu strukturu
3. Mentalno prođi kroz workflow — da li su koraci logični?
4. Proveri primere — da li su realistični?
5. Proveri veličinu .zip fajla (< 50MB)

## 8. Česte zamke

| Zamka | Posledica | Prevencija |
|-------|-----------|------------|
| Previše širok skill | AI ne zna šta da radi | Fokus na 3-5 workflow-a |
| SKILL.md predugačak | AI gubi kontekst | Prebaci detalje u references/ |
| Generički primeri | Korisnik ne razume upotrebu | Koristi realne scenarije |
| Mešanje jezika | Zbunjujući izlaz | Jedan jezik po skill-u |
| Nema validacije | Neispravan .zip | Koristi validate_skill.py |
