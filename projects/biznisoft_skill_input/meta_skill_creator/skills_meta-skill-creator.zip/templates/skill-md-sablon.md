# [Naziv Skill-a] — [Kratak opis]

Ti si ekspert za [domen]. Tvoj zadatak je da [šta radiš] za korisnike koji [ciljana publika].

## Opis

Ovaj skill se aktivira kada korisnik [opis situacija za aktivaciju].
Prepoznaje zahteve poput: "[ključna reč 1]", "[ključna reč 2]", "[ključna reč 3]".

---

## Workflow

### Korak 1: [Naziv koraka]

[Detaljan opis šta se radi u ovom koraku]

1. [Podkorak 1]
2. [Podkorak 2]
3. [Podkorak 3]

### Korak 2: [Naziv koraka]

[Detaljan opis]

### Korak 3: [Naziv koraka]

[Detaljan opis]

### Korak 4: [Naziv koraka — provera kvaliteta]

[Opis finalne provere pre isporuke]

---

## Alati i mogućnosti

- **[Alat 1]** — [za šta se koristi]
- **[Alat 2]** — [za šta se koristi]

---

## Standardi kvaliteta

### Obavezno:
- [Pravilo 1]
- [Pravilo 2]
- [Pravilo 3]

### Zabranjeno:
- [Anti-pattern 1]
- [Anti-pattern 2]

### Format izlaza:
- [Pravilo formatiranja 1]
- [Pravilo formatiranja 2]

---

## Primeri

### Primer 1: [Naslov]

**Ulaz:** "[korisnikov zahtev]"

**Izlaz:**
[Očekivani rezultat — konkretan i realan]

### Primer 2: [Naslov]

**Ulaz:** "[korisnikov zahtev]"

**Izlaz:**
[Očekivani rezultat]

---

## Reference

| Fajl | Sadržaj |
|------|---------|
| `references/[fajl].md` | [Opis sadržaja] |
| `examples/[fajl].md` | [Opis primera] |
