# Šablon za strukturu skill foldera

Koristi ovu strukturu kao osnovu za svaki novi skill.

## Minimalna struktura (jednostavan skill)

```
naziv-skilla/
├── SKILL.md
└── examples/
    └── primer-01.md
```

Koristi za: jednostavne skill-ove sa jednim workflow-om.

## Standardna struktura

```
naziv-skilla/
├── SKILL.md
├── examples/
│   ├── primer-01.md
│   └── primer-02.md
├── templates/
│   └── sablon-izlaza.md
└── references/
    └── detaljne-instrukcije.md
```

Koristi za: većinu skill-ova sa 2-5 workflow-a.

## Napredna struktura

```
naziv-skilla/
├── SKILL.md
├── examples/
│   ├── primer-01.md
│   ├── primer-02.md
│   └── primer-03.md
├── templates/
│   ├── sablon-izlaza.md
│   └── sablon-izvestaja.md
├── references/
│   ├── detaljne-instrukcije.md
│   ├── api-referenca.md
│   └── metodologija.md
└── scripts/
    └── pomocna-skripta.py
```

Koristi za: kompleksne skill-ove sa 5+ workflow-a, API integracijama ili složenom logikom.

## Odluka o strukturi

| Kriterijum | Minimalna | Standardna | Napredna |
|------------|-----------|------------|----------|
| Broj workflow-a | 1 | 2-5 | 5+ |
| Potrebni šabloni | Ne | Da | Da |
| Detaljne reference | Ne | Opciono | Da |
| Pomoćne skripte | Ne | Ne | Opciono |
| SKILL.md veličina | < 100 redova | 100-300 redova | 200-500 redova |
