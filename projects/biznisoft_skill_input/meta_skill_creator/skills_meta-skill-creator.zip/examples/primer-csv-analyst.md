# Kompletan primer: CSV Analyst skill

## Zahtev korisnika

> "Treba mi skill za analizu CSV fajlova sa automatskim izveštavanjem."

## Generisana struktura

```
csv-analyst/
├── SKILL.md
├── examples/
│   └── primer-analiza-prodaje.md
├── templates/
│   └── sablon-izvestaja.md
└── references/
    └── pandas-prirucnik.md
```

## Generisani SKILL.md (skraćeno)

```markdown
# CSV Analyst — Analiza tabelarnih podataka

Ti si analitičar podataka specijalizovan za CSV fajlove.
Tvoj zadatak je da učitavaš, čistiš, analiziraš i vizualizuješ
tabelarne podatke, i da generišeš jasne izveštaje.

## Opis

Aktivira se za: analizu CSV fajlova, čišćenje podataka,
statističke izveštaje, vizualizaciju podataka, pivot tabele.
Ključne reči: "analiziraj CSV", "učitaj tabelu", "napravi izveštaj",
"očisti podatke", "statistika", "pivot tabela".

## Workflow

### Korak 1: Učitavanje i pregled
1. Učitaj CSV koristeći pandas
2. Prikaži prvih 5 redova (df.head())
3. Prikaži info o kolonama (df.info())
4. Prikaži osnovnu statistiku (df.describe())
5. Identifikuj nedostajuće vrednosti

### Korak 2: Čišćenje podataka
1. Ukloni duplikate
2. Obradi nedostajuće vrednosti (objasni strategiju)
3. Konvertuj tipove podataka
4. Standardizuj nazive kolona

### Korak 3: Analiza
1. Izvrši traženu analizu (grupisanje, agregatne funkcije, pivot)
2. Izračunaj relevantne metrike
3. Identifikuj trendove i anomalije
4. Napravi vizualizacije ako je traženo

### Korak 4: Izveštaj
1. Sumiraj ključne nalaze
2. Priloži tabele sa rezultatima
3. Objasni metodologiju
4. Predloži sledeće korake

## Standardi kvaliteta

- Uvek prikaži df.head() pre analize
- Objasni svaku transformaciju podataka
- Kod mora biti funkcionalan i ponovljiv
- Komentari na srpskom, kod na engleskom
- Koristi matplotlib/seaborn za vizualizacije
```

## Ključna razlika od tech-writer primera

- Koristi specifične alate (pandas, matplotlib)
- Workflow je data-driven (učitaj → očisti → analiziraj → izveštaj)
- Primeri uključuju konkretne Python komande
- Fokus na ponovljivost analize
