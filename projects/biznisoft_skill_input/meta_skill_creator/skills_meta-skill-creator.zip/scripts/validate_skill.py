#!/usr/bin/env python3
"""Validacija Abacus.AI skill paketa.

Proverava da li skill folder ima ispravnu strukturu,
obavezne sekcije u SKILL.md, i da nema praznih fajlova.

Koriscenje:
    python3 validate_skill.py /putanja/do/skill-foldera/
"""

import sys
import os
from pathlib import Path


def validate_skill(skill_path: str) -> list:
    """Validira skill folder i vraca listu gresaka.

    Args:
        skill_path: Putanja do skill foldera.

    Returns:
        Lista stringova sa opisima gresaka. Prazna lista = sve OK.
    """
    errors = []
    warnings = []
    skill_dir = Path(skill_path)

    # 1. Proveri da folder postoji
    if not skill_dir.is_dir():
        errors.append(f"Folder ne postoji: {skill_path}")
        return errors

    # 2. Proveri da SKILL.md postoji
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.is_file():
        errors.append("SKILL.md ne postoji na root nivou foldera")
        return errors

    # 3. Proveri sadrzaj SKILL.md
    content = skill_md.read_text(encoding="utf-8")
    lines = content.strip().split("\n")

    if len(lines) < 10:
        errors.append(f"SKILL.md je prekratak ({len(lines)} redova, minimum 10)")

    if len(lines) > 500:
        warnings.append(f"SKILL.md je predugacak ({len(lines)} redova, preporuka < 500). Prebaci detalje u references/")

    # 4. Proveri obavezne sekcije
    required_sections = ["workflow", "kvalitet", "primer"]
    content_lower = content.lower()
    for section in required_sections:
        if section not in content_lower:
            errors.append(f"SKILL.md ne sadrzi sekciju sa kljucnom recju '{section}'")

    # 5. Proveri da nema TODO/FIXME/placeholder markera
    # Ignorisi redove koji opisuju pravila (sadrze "zabranjeno", "nikada", "nema", "ne sme")
    rule_context_words = ["zabranjeno", "nikada", "nema ", "ne sme", "forbidden", "never", "zabranjen",
                         "- todo,", "- fixme,", "placeholder komentari"]
    forbidden_markers = ["TODO", "FIXME", "PLACEHOLDER", "INSERT_HERE", "YOUR_"]
    for i, line in enumerate(lines, 1):
        line_lower = line.lower()
        if any(ctx in line_lower for ctx in rule_context_words):
            continue  # Ovo je opis pravila, ne stvarni marker
        for marker in forbidden_markers:
            if marker in line:
                errors.append(f"SKILL.md red {i}: sadrzi zabranjeni marker '{marker}'")

    # 6. Proveri prazne fajlove
    for f in skill_dir.rglob("*"):
        if f.is_file() and f.suffix in (".md", ".txt", ".py", ".json"):
            if f.stat().st_size == 0:
                errors.append(f"Prazan fajl: {f.relative_to(skill_dir)}")

    # 7. Proveri naziv skill-a (lowercase sa crticama)
    skill_name = skill_dir.name
    if skill_name != skill_name.lower():
        errors.append(f"Naziv foldera mora biti lowercase: '{skill_name}'")
    if " " in skill_name:
        errors.append(f"Naziv foldera ne sme imati razmake: '{skill_name}'")
    if not all(c.isalnum() or c == "-" or c == "_" for c in skill_name):
        errors.append(f"Naziv foldera sme imati samo slova, brojeve, crtice i donje crte: '{skill_name}'")

    # 8. Proveri velicinu za .zip (ako postoji)
    for f in skill_dir.glob("*.zip"):
        size_mb = f.stat().st_size / (1024 * 1024)
        if size_mb > 50:
            errors.append(f".zip fajl je prevelik ({size_mb:.1f}MB, max 50MB): {f.name}")

    # Ispis rezultata
    if errors:
        print(f"\n\u274c VALIDACIJA NEUSPESNA za: {skill_path}")
        print(f"   Pronadjeno {len(errors)} gresaka:\n")
        for e in errors:
            print(f"   \u2022 {e}")
    else:
        print(f"\n\u2705 VALIDACIJA USPESNA za: {skill_path}")
        print(f"   Skill paket je ispravan.")

    if warnings:
        print(f"\n   \u26a0\ufe0f  Upozorenja ({len(warnings)}):")
        for w in warnings:
            print(f"   \u2022 {w}")

    print()
    return errors


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Koriscenje: python3 validate_skill.py /putanja/do/skill-foldera/")
        sys.exit(1)

    errors = validate_skill(sys.argv[1])
    sys.exit(1 if errors else 0)
