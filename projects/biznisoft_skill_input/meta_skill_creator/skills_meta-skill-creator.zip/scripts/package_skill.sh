#!/bin/bash
# Pakuje skill folder u .zip za upload na Abacus.AI.
#
# Koriscenje:
#   bash package_skill.sh naziv-skilla
#
# .zip ce biti sacuvan u /home/ubuntu/.skills/naziv-skilla/naziv-skilla.zip

set -e

SKILL_NAME="${1:?Greska: Navedi naziv skill-a kao prvi argument}"
BASE_DIR="/home/ubuntu/.skills/${SKILL_NAME}"
ZIP_FILE="${BASE_DIR}/${SKILL_NAME}.zip"

# Proveri da folder postoji
if [ ! -d "$BASE_DIR" ]; then
    echo "Greska: Folder ne postoji: $BASE_DIR"
    exit 1
fi

# Proveri da SKILL.md postoji
if [ ! -f "$BASE_DIR/SKILL.md" ]; then
    echo "Greska: SKILL.md ne postoji u $BASE_DIR"
    exit 1
fi

# Obrisi stari .zip ako postoji
if [ -f "$ZIP_FILE" ]; then
    rm "$ZIP_FILE"
    echo "Obrisan stari: $ZIP_FILE"
fi

# Kreiraj .zip (SKILL.md mora biti na root nivou)
cd "$BASE_DIR"
zip -r "$ZIP_FILE" \
    SKILL.md \
    examples/ templates/ references/ scripts/ \
    -x "*.zip" "*.pyc" "__pycache__/*" ".gitkeep" "*.pdf" \
    2>/dev/null || true

# Proveri velicinu
SIZE_MB=$(du -m "$ZIP_FILE" | cut -f1)
if [ "$SIZE_MB" -gt 50 ]; then
    echo "UPOZORENJE: .zip je ${SIZE_MB}MB (max dozvoljeno: 50MB)"
    exit 1
fi

echo ""
echo "Skill uspesno spakovan!"
echo "Fajl: $ZIP_FILE"
echo "Velicina: ${SIZE_MB}MB"
echo ""
echo "Sledeci korak: Upload na Abacus.AI"
echo "  1. Otvori Profile > Customize & Add Skills"
echo "  2. Klikni + New Skill"
echo "  3. Upload fajl: $ZIP_FILE"
