#!/bin/bash
# Kreira strukturu foldera za novi Abacus.AI skill.
#
# Koriscenje:
#   bash create_skill_structure.sh naziv-skilla [minimalna|standardna|napredna]
#
# Primeri:
#   bash create_skill_structure.sh tech-writer
#   bash create_skill_structure.sh csv-analyst standardna
#   bash create_skill_structure.sh complex-tool napredna

set -e

SKILL_NAME="${1:?Greska: Navedi naziv skill-a kao prvi argument}"
STRUCTURE="${2:-standardna}"
BASE_DIR="/home/ubuntu/.skills/${SKILL_NAME}"

# Proveri da folder ne postoji
if [ -d "$BASE_DIR" ]; then
    echo "Greska: Folder vec postoji: $BASE_DIR"
    echo "Obrisi ga prvo ili izaberi drugi naziv."
    exit 1
fi

# Kreiraj osnovnu strukturu
mkdir -p "$BASE_DIR"
echo "Kreiran folder: $BASE_DIR"

# Kreiraj SKILL.md sa osnovnim sadrzajem
cat > "$BASE_DIR/SKILL.md" << 'EOF'
# [Naziv Skill-a] — [Kratak opis]

Ti si ekspert za [domen]. Tvoj zadatak je da [sta radis].

## Opis

Ovaj skill se aktivira kada korisnik [situacije za aktivaciju].

## Workflow

### Korak 1: [Naziv]
[Opis]

### Korak 2: [Naziv]
[Opis]

### Korak 3: [Naziv]
[Opis]

## Alati i mogucnosti

- **[Alat]** — [za sta se koristi]

## Standardi kvaliteta

- [Pravilo 1]
- [Pravilo 2]

## Primeri

### Primer 1: [Naslov]
**Ulaz:** "[zahtev]"
**Izlaz:** [rezultat]

### Primer 2: [Naslov]
**Ulaz:** "[zahtev]"
**Izlaz:** [rezultat]
EOF

# Minimalna struktura
mkdir -p "$BASE_DIR/examples"
touch "$BASE_DIR/examples/.gitkeep"

# Standardna struktura
if [ "$STRUCTURE" = "standardna" ] || [ "$STRUCTURE" = "napredna" ]; then
    mkdir -p "$BASE_DIR/templates"
    mkdir -p "$BASE_DIR/references"
    touch "$BASE_DIR/templates/.gitkeep"
    touch "$BASE_DIR/references/.gitkeep"
fi

# Napredna struktura
if [ "$STRUCTURE" = "napredna" ]; then
    mkdir -p "$BASE_DIR/scripts"
    touch "$BASE_DIR/scripts/.gitkeep"
fi

echo ""
echo "Skill struktura kreirana uspesno!"
echo "Lokacija: $BASE_DIR"
echo "Struktura: $STRUCTURE"
echo ""
echo "Sledeci koraci:"
echo "  1. Izmeni SKILL.md sa konkretnim sadrzajem"
echo "  2. Dodaj primere u examples/"
if [ "$STRUCTURE" != "minimalna" ]; then
    echo "  3. Dodaj sablone u templates/"
    echo "  4. Dodaj reference u references/"
fi
echo "  5. Pokreni validaciju: python3 scripts/validate_skill.py $BASE_DIR"
echo "  6. Spakuj: bash scripts/package_skill.sh $SKILL_NAME"
