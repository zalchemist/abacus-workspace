# MariaDB Toolkit v2

> Poboljšani MariaDB toolkit za upravljanje, konfiguraciju i analizu baza podataka  
> Optimizovan za BizniSoft ERP baze na serverima sa velikim količinama RAM-a

---

## 📋 Promene u v2 (Changelog)

### Rešeni problemi iz v1:

| Problem | Rešenje u v2 |
|---------|-------------|
| **Hardkodirane putanje** u skriptama | Sve putanje parametrizovane kroz env varijable i argumente |
| **Nema logovanja akcija** toolkit-a | Automatsko beleženje svih akcija u log fajl sa timestamp-om |
| **`parse_sql_dump.py` nije parametrizovan** | Prima SQL fajl kao argument, podržava bilo koji dump |
| **Nedostaju before/after snapshot-ovi** | Nova `snapshot` i `compare` komanda + automatski snapshot-ovi pri konfiguraciji |

### Nove funkcionalnosti:

- ✅ **Automatsko logovanje** - sve akcije se beleže u `logs/toolkit_YYYYMMDD.log`
- ✅ **Before/After snapshot** - komande `snapshot`, `compare`, `snapshots` za praćenje promena
- ✅ **Parametrizovane putanje** - konfigurisanje putem env varijabli (`TOOLKIT_LOG_DIR`, `TOOLKIT_PERF_CNF`, `TOOLKIT_SNAPSHOT_DIR`, `TOOLKIT_CNF_DIR`)
- ✅ **Parametrizovan SQL parser** - `parse_sql_dump.py` prima fajl i output dir kao argumente
- ✅ **Auto-detekcija** MariaDB config direktorijuma
- ✅ **Log fajl za parser** - `parse_log.txt` sa vremenskim oznakama za svaki korak parsiranja

---

## 📁 Sadržaj toolkit-a

| Fajl | Namena | Novo u v2 |
|------|--------|-----------|
| `mariadb_toolkit.sh` | Glavni alat za upravljanje bazama | ✅ Poboljšan |
| `mariadb_performance.cnf` | Konfiguracioni fajl za performanse | Nepromenjen |
| `quick_setup.sh` | Brza instalacija i konfiguracija | ✅ Poboljšan |
| `parse_sql_dump.py` | Python parser za analizu SQL dump-ova | ✅ Potpuno prepravljeno |
| `README.md` | Dokumentacija | ✅ Nova verzija |
| `logs/` | Direktorijum za log fajlove | ✅ Novo |
| `snapshots/` | Direktorijum za snapshot-ove podešavanja | ✅ Novo |

---

## 🚀 Brzi početak

### Opcija 1: Brza instalacija (preporučeno)

```bash
sudo bash quick_setup.sh
```

Ovo će:
1. Instalirati MariaDB server & klijent
2. Snimiti BEFORE snapshot trenutnih podešavanja
3. Kopirati performance konfiguraciju
4. Pokrenuti/restartovati MariaDB
5. Verifikovati podešavanja i snimiti AFTER snapshot

### Opcija 2: Korak po korak

```bash
# 1. Proveri resurse sistema
bash mariadb_toolkit.sh check

# 2. Snimi početno stanje
bash mariadb_toolkit.sh snapshot pre_konfig

# 3. Instaliraj i konfiguriši
sudo bash mariadb_toolkit.sh setup

# 4. Snimi novo stanje i uporedi
bash mariadb_toolkit.sh snapshot posle_konfig
bash mariadb_toolkit.sh compare pre_konfig posle_konfig

# 5. Verifikuj
bash mariadb_toolkit.sh status
```

---

## 📖 Kompletna referenca komandi

### Sistem i podešavanje

```bash
bash mariadb_toolkit.sh check         # Proveri resurse sistema
sudo bash mariadb_toolkit.sh install   # Instaliraj MariaDB
sudo bash mariadb_toolkit.sh configure # Primeni optimizovanu konfiguraciju (auto-snapshot)
sudo bash mariadb_toolkit.sh setup     # Kompletno podešavanje: install + configure
```

### Operacije sa bazama

```bash
# Import SQL dump-a
sudo bash mariadb_toolkit.sh import /putanja/do/dump.sql ime_baze

# Export baze u SQL dump
bash mariadb_toolkit.sh export ime_baze /putanja/do/output.sql

# Lista svih baza sa veličinama
bash mariadb_toolkit.sh list

# Statistika za određenu bazu
bash mariadb_toolkit.sh stats ime_baze
```

### Monitoring i upravljanje

```bash
bash mariadb_toolkit.sh status        # Status MariaDB servisa
bash mariadb_toolkit.sh performance   # Trenutna konfiguracija performansi
sudo bash mariadb_toolkit.sh restart   # Restart MariaDB servisa
```

### Snapshot-ovi (NOVO u v2)

```bash
bash mariadb_toolkit.sh snapshot pre_izmena    # Snimi trenutno stanje
bash mariadb_toolkit.sh snapshot posle_izmena  # Snimi stanje nakon promena
bash mariadb_toolkit.sh compare pre_izmena posle_izmena  # Uporedi dva snapshot-a
bash mariadb_toolkit.sh snapshots              # Lista svih snapshot-ova
```

### SQL Dump Parser (NOVO u v2)

```bash
# Parsiranje bilo kog SQL dump fajla
python3 parse_sql_dump.py /putanja/do/dump.sql

# Sa specifičnim output direktorijumom
python3 parse_sql_dump.py /putanja/do/dump.sql /putanja/do/output/

# Primeri za BizniSoft baze
python3 parse_sql_dump.py /home/ubuntu/db_dumps/opp7102025.sql
python3 parse_sql_dump.py /home/ubuntu/db_dumps/opp.sql ./analiza_opp
```

---

## ⚙️ Konfigurisanje putem environment varijabli

| Varijabla | Podrazumevana vrednost | Opis |
|-----------|----------------------|------|
| `TOOLKIT_LOG_DIR` | `./logs` | Direktorijum za log fajlove |
| `TOOLKIT_PERF_CNF` | `./mariadb_performance.cnf` | Putanja do performance .cnf fajla |
| `TOOLKIT_SNAPSHOT_DIR` | `./snapshots` | Direktorijum za snapshot-ove |
| `TOOLKIT_CNF_DIR` | Auto-detected | MariaDB config direktorijum |

### Primer korišćenja sa custom putanjama:

```bash
TOOLKIT_LOG_DIR=/var/log/mariadb_toolkit \
TOOLKIT_PERF_CNF=/etc/mariadb_custom.cnf \
bash mariadb_toolkit.sh configure
```

---

## 📊 Logovanje

Sve akcije se automatski beleže u:
- `logs/toolkit_YYYYMMDD.log` - dnevni log za toolkit komande
- `logs/quick_setup_YYYYMMDD.log` - log za quick setup
- `analysis_<dbname>/parse_log.txt` - log za SQL parser

### Format log zapisa:
```
[2026-03-29 14:30:15] [INFO] Toolkit invoked: ./mariadb_toolkit.sh import dump.sql mydb
[2026-03-29 14:30:15] [OK] Database 'mydb' ready
[2026-03-29 14:35:22] [OK] Import completed in 5m 7s
```

---

## 📸 Before/After Snapshot-ovi

Snapshot sistem snima kompletno stanje MariaDB servera:
- Sve globalne varijable (`SHOW GLOBAL VARIABLES`)
- Status servera (`SHOW GLOBAL STATUS`)
- Lista baza sa veličinama
- Sadržaj aktivnog konfiguracionog fajla

### Automatski snapshot-ovi:
- `configure` komanda automatski pravi BEFORE i AFTER snapshot
- `quick_setup.sh` automatski pravi BEFORE i AFTER snapshot

### Primer workflow-a:
```bash
# 1. Snimi početno stanje
bash mariadb_toolkit.sh snapshot baseline

# 2. Uradi promene (npr. import baze, promena konfiguracije)
sudo bash mariadb_toolkit.sh import dump.sql nova_baza

# 3. Snimi novo stanje
bash mariadb_toolkit.sh snapshot posle_importa

# 4. Uporedi šta se promenilo
bash mariadb_toolkit.sh compare baseline posle_importa
```

---

## ⚙️ Performance konfiguracija

`mariadb_performance.cnf` je optimizovan za server sa **61GB RAM** i **8 CPU jezgara**:

| Podešavanje | Vrednost | Namena |
|------------|---------|--------|
| `innodb_buffer_pool_size` | 40GB | Glavni keš za podatke/indekse (65% RAM-a) |
| `innodb_buffer_pool_instances` | 8 | Paralelni pristup buffer pool-u |
| `innodb_log_file_size` | 1GB | Write-ahead log |
| `query_cache_size` | 256MB | Keš za ponovljene SELECT upite |
| `max_allowed_packet` | 1GB | Veliki dump import-i bez grešaka |
| `wait_timeout` | 86400s (24h) | Sprečava "server gone away" greške |
| `max_connections` | 200 | Limit istovremenih konekcija |
| `tmp_table_size` | 512MB | In-memory temp tabele |
| `slow_query_log` | ON | Loguje upite sporije od 2 sekunde |

---

## 🗄️ BizniSoft ERP baze

| Baza | Tabele | Opis |
|------|--------|------|
| `opp` | 196 | Sistemska/konfiguraciona baza |
| `opp7102025` | 644 | Operativna/transakciona baza (643 tabela + 1 view) |

**Karakteristike šeme:** 265 trigera, 149 stored procedura/funkcija, 1 view, 0 foreign key-ova

### Import BizniSoft baza:

```bash
sudo bash mariadb_toolkit.sh import /home/ubuntu/db_dumps/opp.sql opp
sudo bash mariadb_toolkit.sh import /home/ubuntu/db_dumps/opp7102025.sql opp7102025
```

---

## 🔄 Nakon restarta VM-a

```bash
# 1. Brzo podešavanje
sudo bash /home/ubuntu/mariadb_toolkit_v2/quick_setup.sh

# 2. Re-import baza
sudo bash /home/ubuntu/mariadb_toolkit_v2/mariadb_toolkit.sh import /home/ubuntu/db_dumps/opp.sql opp
sudo bash /home/ubuntu/mariadb_toolkit_v2/mariadb_toolkit.sh import /home/ubuntu/db_dumps/opp7102025.sql opp7102025

# 3. Verifikacija
bash /home/ubuntu/mariadb_toolkit_v2/mariadb_toolkit.sh list
bash /home/ubuntu/mariadb_toolkit_v2/mariadb_toolkit.sh performance
```

---

## 📋 Važne napomene

- **Root/sudo** je potreban za install, configure, restart i import operacije
- **Config lokacija**: Deployment na `/etc/mysql/mariadb.conf.d/99-performance.cnf`
- **Slow query log**: `/var/log/mysql/slow.log`
- **VM perzistentnost**: `/home/ubuntu/` direktorijum je trajan; `/etc/` nije
- **Uvek čuvaj backup-e**: Exportuj baze pre velikih promena
- **Log fajlovi** se čuvaju u `logs/` direktorijumu toolkit-a

---

*MariaDB Toolkit v2 | Generisano: 2026-03-29 | MariaDB 10.11.14*
