#!/usr/bin/env python3
"""
SQL Dump Parser v2 - Parametrized for any SQL dump file
=========================================================
Parses a MySQL/MariaDB dump file in READ-ONLY mode and extracts:
  - Table structures (columns, types, keys, indexes)
  - Foreign key relationships
  - Triggers
  - Stored procedures and functions
  - Views
  - Summary report

v2 Improvements:
  - Accepts SQL file path as command-line argument
  - Accepts output directory as optional argument
  - Auto-detects database name from dump file
  - All actions logged with timestamps
  - Can be used with any SQL dump, not just opp7102025

Usage:
  python3 parse_sql_dump.py <sql_file> [output_dir]
  python3 parse_sql_dump.py /path/to/dump.sql
  python3 parse_sql_dump.py /path/to/dump.sql /path/to/output/

The original SQL file is NEVER modified.
"""

import re
import json
import os
import sys
import logging
from datetime import datetime
from collections import Counter, defaultdict

# ============================================================================
# ARGUMENT PARSING & CONFIGURATION
# ============================================================================

def print_usage():
    """Print usage information."""
    script_name = os.path.basename(sys.argv[0])
    print(f"""
SQL Dump Parser v2
==================

Usage:
  python3 {script_name} <sql_file> [output_dir]

Arguments:
  sql_file    - Path to the SQL dump file to parse (required)
  output_dir  - Directory for output files (optional, default: ./analysis_<dbname>)

Examples:
  python3 {script_name} /home/ubuntu/db_dumps/opp7102025.sql
  python3 {script_name} /home/ubuntu/db_dumps/opp.sql /tmp/opp_analysis
  python3 {script_name} dump.sql ./output

Output files:
  tables_structure.json  - Table structures with columns, keys, indexes
  relationships.json     - Foreign key relationships
  triggers.json          - Trigger definitions
  procedures.json        - Stored procedures and functions
  views.json             - View definitions
  schema_report.md       - Human-readable summary report
  parse_log.txt          - Execution log with timestamps
""")


def parse_args():
    """Parse command-line arguments."""
    if len(sys.argv) < 2 or sys.argv[1] in ('-h', '--help', 'help'):
        print_usage()
        sys.exit(0 if len(sys.argv) > 1 else 1)

    sql_file = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None

    if not os.path.isfile(sql_file):
        print(f"ERROR: SQL file not found: {sql_file}")
        sys.exit(1)

    return sql_file, output_dir


def detect_database_name(sql_file, content=None):
    """Try to detect database name from the SQL dump file."""
    # Try from filename first
    basename = os.path.basename(sql_file)
    name = os.path.splitext(basename)[0]

    # Try to find CREATE DATABASE statement in content
    if content:
        match = re.search(r'CREATE\s+DATABASE.*?`(\w+)`', content[:5000], re.IGNORECASE)
        if match:
            return match.group(1)
        # Try USE statement
        match = re.search(r'^USE\s+`?(\w+)`?;', content[:5000], re.MULTILINE | re.IGNORECASE)
        if match:
            return match.group(1)

    return name


# ============================================================================
# LOGGING SETUP
# ============================================================================

def setup_logging(output_dir):
    """Setup logging to both console and file."""
    log_file = os.path.join(output_dir, "parse_log.txt")
    logging.basicConfig(
        level=logging.INFO,
        format='[%(asctime)s] %(levelname)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)


# ============================================================================
# PARSING FUNCTIONS
# ============================================================================

def read_file(sql_file, logger):
    """Read the entire SQL dump into memory."""
    logger.info(f"Reading {sql_file} ...")
    file_size = os.path.getsize(sql_file)
    logger.info(f"  File size: {file_size / 1024 / 1024:.1f} MB")
    with open(sql_file, "r", encoding="utf-8") as f:
        content = f.read()
    logger.info(f"  Read {len(content):,} characters")
    return content


def parse_tables(content, logger):
    """Extract all CREATE TABLE blocks and parse their columns, keys, indexes."""
    tables = []

    table_pattern = re.compile(
        r'CREATE TABLE\s+`(\w+)`\s*\(\s*\n(.*?)\n\)\s*ENGINE\s*=\s*(\w+)(.*?);',
        re.DOTALL
    )

    for match in table_pattern.finditer(content):
        table_name = match.group(1)
        body = match.group(2)
        engine = match.group(3)
        extra = match.group(4)

        columns = []
        primary_keys = []
        indexes = []
        foreign_keys = []

        auto_inc_table = None
        ai_match = re.search(r'AUTO_INCREMENT\s*=\s*(\d+)', extra)
        if ai_match:
            auto_inc_table = int(ai_match.group(1))

        for line in body.split('\n'):
            line = line.strip().rstrip(',')
            if not line:
                continue

            # Column definition
            col_match = re.match(
                r'^`(\w+)`\s+'
                r'(\w+(?:\([^)]*\))?)'
                r'\s*(.*)',
                line
            )
            if col_match:
                col_name = col_match.group(1)
                col_type = col_match.group(2)
                col_rest = col_match.group(3)

                nullable = "NOT NULL" not in col_rest.upper()
                default = None
                def_match = re.search(
                    r"DEFAULT\s+(NULL|CURRENT_TIMESTAMP|'[^']*'|\"[^\"]*\"|\d+(?:\.\d+)?)",
                    col_rest, re.IGNORECASE
                )
                if def_match:
                    default = def_match.group(1)

                auto_increment = bool(re.search(r'AUTO_INCREMENT', col_rest, re.IGNORECASE))
                on_update = None
                ou_match = re.search(r'ON UPDATE\s+(CURRENT_TIMESTAMP)', col_rest, re.IGNORECASE)
                if ou_match:
                    on_update = ou_match.group(1)

                columns.append({
                    "name": col_name,
                    "type": col_type,
                    "nullable": nullable,
                    "default": default,
                    "auto_increment": auto_increment,
                    "on_update": on_update
                })
                continue

            # PRIMARY KEY
            pk_match = re.match(r'^PRIMARY\s+KEY\s*\(([^)]+)\)', line, re.IGNORECASE)
            if pk_match:
                pk_cols = re.findall(r'`(\w+)`', pk_match.group(1))
                primary_keys = pk_cols
                continue

            # INDEX / KEY
            idx_match = re.match(
                r'^(UNIQUE\s+)?(INDEX|KEY)\s+`(\w+)`\s*\(([^)]+)\)',
                line, re.IGNORECASE
            )
            if idx_match:
                is_unique = idx_match.group(1) is not None
                idx_name = idx_match.group(3)
                idx_cols = re.findall(r'`(\w+)`', idx_match.group(4))
                indexes.append({
                    "name": idx_name,
                    "columns": idx_cols,
                    "unique": is_unique
                })
                continue

            # FOREIGN KEY
            fk_match = re.match(
                r'^(?:CONSTRAINT\s+`(\w+)`\s+)?FOREIGN\s+KEY\s*\(([^)]+)\)\s*'
                r'REFERENCES\s+`(\w+)`\s*\(([^)]+)\)'
                r'(?:\s+ON\s+DELETE\s+(RESTRICT|CASCADE|SET\s+NULL|NO\s+ACTION|SET\s+DEFAULT))?'
                r'(?:\s+ON\s+UPDATE\s+(RESTRICT|CASCADE|SET\s+NULL|NO\s+ACTION|SET\s+DEFAULT))?',
                line, re.IGNORECASE
            )
            if fk_match:
                foreign_keys.append({
                    "constraint_name": fk_match.group(1),
                    "source_columns": re.findall(r'`(\w+)`', fk_match.group(2)),
                    "target_table": fk_match.group(3),
                    "target_columns": re.findall(r'`(\w+)`', fk_match.group(4)),
                    "on_delete": fk_match.group(5),
                    "on_update": fk_match.group(6)
                })

        tables.append({
            "table_name": table_name,
            "engine": engine,
            "auto_increment_value": auto_inc_table,
            "columns": columns,
            "primary_keys": primary_keys,
            "indexes": indexes,
            "foreign_keys": foreign_keys,
            "column_count": len(columns)
        })

    logger.info(f"  Parsed {len(tables)} tables")
    return tables


def extract_relationships(tables, logger):
    """Collect all foreign key relationships from parsed tables."""
    relationships = []
    for table in tables:
        for fk in table["foreign_keys"]:
            relationships.append({
                "source_table": table["table_name"],
                "source_columns": fk["source_columns"],
                "target_table": fk["target_table"],
                "target_columns": fk["target_columns"],
                "constraint_name": fk["constraint_name"],
                "on_delete": fk["on_delete"],
                "on_update": fk["on_update"]
            })
    logger.info(f"  Found {len(relationships)} foreign key relationships")
    return relationships


def parse_triggers(content, logger):
    """Extract CREATE TRIGGER definitions."""
    triggers = []

    block_pattern = re.compile(
        r'delimiter\s+;;\s*\n(.*?)\ndelimiter\s+;\s*',
        re.DOTALL | re.IGNORECASE
    )

    for block_match in block_pattern.finditer(content):
        block = block_match.group(1).strip()

        trigger_match = re.match(
            r'CREATE\s+TRIGGER\s+`(\w+)`\s+'
            r'(BEFORE|AFTER)\s+'
            r'(INSERT|UPDATE|DELETE)\s+'
            r'ON\s+`(\w+)`\s+'
            r'FOR\s+EACH\s+ROW\s*'
            r'(.*)',
            block, re.DOTALL | re.IGNORECASE
        )
        if trigger_match:
            body = trigger_match.group(5).strip()
            if body.endswith(';;'):
                body = body[:-2].strip()

            triggers.append({
                "trigger_name": trigger_match.group(1),
                "timing": trigger_match.group(2).upper(),
                "event": trigger_match.group(3).upper(),
                "table": trigger_match.group(4),
                "body": body
            })

    logger.info(f"  Parsed {len(triggers)} triggers")
    return triggers


def parse_procedures(content, logger):
    """Extract CREATE PROCEDURE and CREATE FUNCTION definitions."""
    procedures = []

    block_pattern = re.compile(
        r'delimiter\s+;;\s*\n(.*?)\ndelimiter\s+;\s*',
        re.DOTALL | re.IGNORECASE
    )

    for block_match in block_pattern.finditer(content):
        block = block_match.group(1).strip()

        proc_match = re.match(
            r'CREATE\s+(PROCEDURE|FUNCTION)\s+`(\w+)`\s*'
            r'\((.*?)\)\s*'
            r'(.*)',
            block, re.DOTALL | re.IGNORECASE
        )
        if proc_match:
            obj_type = proc_match.group(1).upper()
            name = proc_match.group(2)
            params_raw = proc_match.group(3).strip()
            rest = proc_match.group(4).strip()

            if rest.endswith(';;'):
                rest = rest[:-2].strip()

            returns_type = None
            body = rest
            if obj_type == "FUNCTION":
                ret_match = re.match(
                    r'RETURNS\s+(\w+(?:\([^)]*\))?)\s*(.*)',
                    rest, re.DOTALL | re.IGNORECASE
                )
                if ret_match:
                    returns_type = ret_match.group(1)
                    body = ret_match.group(2).strip()

            params = []
            if params_raw:
                param_parts = re.split(r',\s*(?![^()]*\))', params_raw)
                for p in param_parts:
                    p = p.strip()
                    if p:
                        pm = re.match(
                            r'(?:(IN|OUT|INOUT)\s+)?`?(\w+)`?\s+(.*)',
                            p, re.IGNORECASE
                        )
                        if pm:
                            params.append({
                                "direction": pm.group(1) if pm.group(1) else "IN",
                                "name": pm.group(2),
                                "type": pm.group(3).strip()
                            })
                        else:
                            params.append({"raw": p})

            procedures.append({
                "type": obj_type,
                "name": name,
                "parameters": params,
                "returns": returns_type,
                "body": body
            })

    logger.info(f"  Parsed {len(procedures)} procedures/functions")
    return procedures


def parse_views(content, logger):
    """Extract CREATE VIEW definitions."""
    views = []

    view_pattern = re.compile(
        r'CREATE\s+'
        r'(?:ALGORITHM\s*=\s*\w+\s+)?'
        r'(?:DEFINER\s*=\s*`[^`]*`@`[^`]*`\s+)?'
        r'(?:SQL\s+SECURITY\s+\w+\s+)?'
        r'VIEW\s+`(\w+)`\s+AS\s+'
        r'(.*?);',
        re.DOTALL | re.IGNORECASE
    )

    for match in view_pattern.finditer(content):
        view_name = match.group(1)
        definition = match.group(2).strip()
        views.append({
            "view_name": view_name,
            "definition": definition
        })

    logger.info(f"  Parsed {len(views)} views")
    return views


# ============================================================================
# REPORT GENERATION
# ============================================================================

def generate_report(db_name, sql_file, tables, relationships, triggers, procedures, views):
    """Generate a human-readable Markdown summary report."""

    total_tables = len(tables)
    total_columns = sum(t["column_count"] for t in tables)
    total_triggers = len(triggers)
    total_procs = len([p for p in procedures if p["type"] == "PROCEDURE"])
    total_funcs = len([p for p in procedures if p["type"] == "FUNCTION"])
    total_views = len(views)
    total_relationships = len(relationships)

    sorted_by_cols = sorted(tables, key=lambda t: t["column_count"], reverse=True)[:20]
    sorted_by_idx = sorted(tables, key=lambda t: len(t["indexes"]), reverse=True)[:10]

    type_counter = Counter()
    for t in tables:
        for c in t["columns"]:
            base_type = re.match(r'(\w+)', c["type"]).group(1).lower()
            type_counter[base_type] += 1

    ai_tables = [t for t in tables if any(c["auto_increment"] for c in t["columns"])]
    ai_tables_sorted = sorted(ai_tables, key=lambda t: t["auto_increment_value"] or 0, reverse=True)[:15]

    trigger_counter = Counter(t["table"] for t in triggers)
    top_trigger_tables = trigger_counter.most_common(15)
    trigger_events = Counter(f"{t['timing']} {t['event']}" for t in triggers)

    composite_pk = [t for t in tables if len(t["primary_keys"]) > 1]
    no_pk = [t for t in tables if not t["primary_keys"]]

    total_nullable = sum(1 for t in tables for c in t["columns"] if c["nullable"])
    total_not_null = total_columns - total_nullable

    file_size_mb = os.path.getsize(sql_file) / 1024 / 1024

    report = f"""# Schema Analysis Report: {db_name}

**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Source File:** `{os.path.basename(sql_file)}` ({file_size_mb:.1f} MB)  
**Parser:** parse_sql_dump.py v2

---

## Overview

| Metric | Count |
|--------|-------|
| Tables | {total_tables} |
| Total Columns | {total_columns:,} |
| Foreign Key Relationships | {total_relationships} |
| Triggers | {total_triggers} |
| Stored Procedures | {total_procs} |
| Stored Functions | {total_funcs} |
| Views | {total_views} |

---

## Top 20 Largest Tables (by Column Count)

| # | Table Name | Columns | Primary Key | Indexes | Auto-Increment |
|---|-----------|---------|-------------|---------|----------------|
"""
    for i, t in enumerate(sorted_by_cols, 1):
        pk = ", ".join(t["primary_keys"]) if t["primary_keys"] else "—"
        ai = "✓" if any(c["auto_increment"] for c in t["columns"]) else "—"
        report += f"| {i} | `{t['table_name']}` | {t['column_count']} | {pk} | {len(t['indexes'])} | {ai} |\n"

    report += f"""
---

## Column Type Distribution

| Data Type | Count | Percentage |
|-----------|-------|------------|
"""
    for dtype, count in type_counter.most_common():
        pct = count / total_columns * 100
        report += f"| `{dtype}` | {count:,} | {pct:.1f}% |\n"

    report += f"""
---

## Nullable vs NOT NULL Columns

| Type | Count | Percentage |
|------|-------|------------|
| Nullable (NULL) | {total_nullable:,} | {total_nullable/total_columns*100:.1f}% |
| NOT NULL | {total_not_null:,} | {total_not_null/total_columns*100:.1f}% |

---

## Tables with Most Indexes

| Table | Index Count | Unique Indexes |
|-------|-------------|----------------|
"""
    for t in sorted_by_idx:
        unique_count = sum(1 for idx in t["indexes"] if idx["unique"])
        report += f"| `{t['table_name']}` | {len(t['indexes'])} | {unique_count} |\n"

    report += f"""
---

## Trigger Analysis

**Total Triggers:** {total_triggers}

#### Trigger Event Distribution

| Event Type | Count |
|-----------|-------|
"""
    for event, count in trigger_events.most_common():
        report += f"| {event} | {count} |\n"

    report += f"""
#### Tables with Most Triggers (Top 15)

| Table | Trigger Count |
|-------|--------------|
"""
    for table, count in top_trigger_tables:
        report += f"| `{table}` | {count} |\n"

    report += f"""
---

## Stored Procedures & Functions

| Type | Count |
|------|-------|
| Procedures | {total_procs} |
| Functions | {total_funcs} |

---

## Views

"""
    if views:
        for v in views:
            report += f"- `{v['view_name']}`: {v['definition'][:200]}...\n"
    else:
        report += "No views found.\n"

    report += f"""
---

## Summary

- **Tables without primary key:** {len(no_pk)}
- **Tables with composite primary keys:** {len(composite_pk)}
- **Foreign key constraints:** {total_relationships}
- **Total triggers:** {total_triggers}
- **Total stored routines:** {total_procs + total_funcs}

---

*Report generated by parse_sql_dump.py v2*
"""
    return report


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    sql_file, output_dir_arg = parse_args()

    # Read file to detect database name
    with open(sql_file, "r", encoding="utf-8") as f:
        header_content = f.read(5000)
    db_name = detect_database_name(sql_file, header_content)

    # Set output directory
    if output_dir_arg:
        output_dir = output_dir_arg
    else:
        output_dir = os.path.join(os.path.dirname(sql_file) or ".", f"analysis_{db_name}")

    os.makedirs(output_dir, exist_ok=True)
    logger = setup_logging(output_dir)

    logger.info("=" * 60)
    logger.info(f"SQL Dump Parser v2 - {db_name}")
    logger.info("=" * 60)
    logger.info(f"SQL file:    {sql_file}")
    logger.info(f"Database:    {db_name}")
    logger.info(f"Output dir:  {output_dir}")

    content = read_file(sql_file, logger)

    logger.info("[1/6] Parsing table structures...")
    tables = parse_tables(content, logger)

    logger.info("[2/6] Extracting relationships...")
    relationships = extract_relationships(tables, logger)

    logger.info("[3/6] Parsing triggers...")
    triggers = parse_triggers(content, logger)

    logger.info("[4/6] Parsing procedures/functions...")
    procedures = parse_procedures(content, logger)

    logger.info("[5/6] Parsing views...")
    views = parse_views(content, logger)

    logger.info("[6/6] Generating report...")
    report = generate_report(db_name, sql_file, tables, relationships, triggers, procedures, views)

    # Save outputs
    logger.info("Saving outputs...")

    tables_out = []
    for t in tables:
        tables_out.append({
            "table_name": t["table_name"],
            "engine": t["engine"],
            "auto_increment_value": t["auto_increment_value"],
            "column_count": t["column_count"],
            "columns": t["columns"],
            "primary_keys": t["primary_keys"],
            "indexes": t["indexes"]
        })

    with open(os.path.join(output_dir, "tables_structure.json"), "w", encoding="utf-8") as f:
        json.dump(tables_out, f, indent=2, ensure_ascii=False)
    logger.info(f"  ✓ tables_structure.json ({len(tables_out)} tables)")

    with open(os.path.join(output_dir, "relationships.json"), "w", encoding="utf-8") as f:
        json.dump(relationships, f, indent=2, ensure_ascii=False)
    logger.info(f"  ✓ relationships.json ({len(relationships)} relationships)")

    with open(os.path.join(output_dir, "triggers.json"), "w", encoding="utf-8") as f:
        json.dump(triggers, f, indent=2, ensure_ascii=False)
    logger.info(f"  ✓ triggers.json ({len(triggers)} triggers)")

    with open(os.path.join(output_dir, "procedures.json"), "w", encoding="utf-8") as f:
        json.dump(procedures, f, indent=2, ensure_ascii=False)
    logger.info(f"  ✓ procedures.json ({len(procedures)} procedures/functions)")

    with open(os.path.join(output_dir, "views.json"), "w", encoding="utf-8") as f:
        json.dump(views, f, indent=2, ensure_ascii=False)
    logger.info(f"  ✓ views.json ({len(views)} views)")

    with open(os.path.join(output_dir, "schema_report.md"), "w", encoding="utf-8") as f:
        f.write(report)
    logger.info(f"  ✓ schema_report.md")

    logger.info("")
    logger.info("=" * 60)
    logger.info(f"DONE! All outputs saved to {output_dir}/")
    logger.info("=" * 60)
