#!/bin/bash
#==============================================================================
# MariaDB Toolkit v2 - Comprehensive Setup & Management Script
# Usage:    bash mariadb_toolkit.sh [command] [arguments]
#
# v2 Improvements:
#   - All paths parameterized (no hardcoded paths)
#   - Automatic logging of all actions to log file with timestamps
#   - Before/after configuration snapshot support
#   - Configurable via environment variables or config file
#==============================================================================
#
# COMMANDS:
#   check       - Check system resources and display optimal MariaDB settings
#   install     - Install MariaDB server + client
#   configure   - Apply optimized MariaDB configuration
#   setup       - Full setup: install + configure + secure
#   import      - Import SQL dump into database
#   export      - Export database to SQL dump
#   list        - List all databases with sizes
#   stats       - Show database statistics
#   status      - Show MariaDB service status
#   restart     - Restart MariaDB service
#   performance - Show current performance config and memory budget
#   snapshot    - Take a settings snapshot (before/after comparison)
#   compare     - Compare two snapshots (before vs after)
#   help        - Show this help message
#
# ENVIRONMENT VARIABLES (override defaults):
#   TOOLKIT_LOG_DIR     - Log directory (default: ./logs)
#   TOOLKIT_CNF_DIR     - MariaDB config directory (auto-detected)
#   TOOLKIT_PERF_CNF    - Path to performance .cnf file
#   TOOLKIT_SNAPSHOT_DIR - Snapshot directory (default: ./snapshots)
#
#==============================================================================

set -e

# ============================================================================
# CONFIGURATION - All paths parameterized
# ============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Configurable paths via environment variables (with sensible defaults)
TOOLKIT_LOG_DIR="${TOOLKIT_LOG_DIR:-${SCRIPT_DIR}/logs}"
TOOLKIT_PERF_CNF="${TOOLKIT_PERF_CNF:-${SCRIPT_DIR}/mariadb_performance.cnf}"
TOOLKIT_SNAPSHOT_DIR="${TOOLKIT_SNAPSHOT_DIR:-${SCRIPT_DIR}/snapshots}"

# Auto-detect MariaDB config directory
if [ -n "$TOOLKIT_CNF_DIR" ]; then
    CNF_TARGET_DIR="$TOOLKIT_CNF_DIR"
elif [ -d /etc/mysql/mariadb.conf.d ]; then
    CNF_TARGET_DIR="/etc/mysql/mariadb.conf.d"
elif [ -d /etc/mysql/conf.d ]; then
    CNF_TARGET_DIR="/etc/mysql/conf.d"
elif [ -d /etc/my.cnf.d ]; then
    CNF_TARGET_DIR="/etc/my.cnf.d"
else
    CNF_TARGET_DIR="/etc/mysql/mariadb.conf.d"
fi
CNF_TARGET_FILE="${CNF_TARGET_DIR}/99-performance.cnf"

# Create necessary directories
mkdir -p "$TOOLKIT_LOG_DIR" "$TOOLKIT_SNAPSHOT_DIR"

# Log file with date
LOG_FILE="${TOOLKIT_LOG_DIR}/toolkit_$(date +%Y%m%d).log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

#------------------------------------------------------------------------------
# LOGGING SYSTEM - All actions logged with timestamps
#------------------------------------------------------------------------------
log_action() {
    local level="$1"
    shift
    local message="$*"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[${timestamp}] [${level}] ${message}" >> "$LOG_FILE"
}

log_info()    { log_action "INFO" "$@"; }
log_success() { log_action "OK" "$@"; }
log_warn()    { log_action "WARN" "$@"; }
log_error()   { log_action "ERROR" "$@"; }

# Combined console + log output helpers
info()    { echo -e "${BLUE}[INFO]${NC} $1"; log_info "$1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; log_success "$1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; log_warn "$1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; log_error "$1"; }
header()  { echo -e "\n${BOLD}${CYAN}=== $1 ===${NC}\n"; log_info "=== $1 ==="; }

# Log script invocation
log_info "Toolkit invoked: $0 $*"
log_info "Script directory: ${SCRIPT_DIR}"
log_info "Log file: ${LOG_FILE}"

#------------------------------------------------------------------------------
# FUNCTION: take_snapshot
# Takes a snapshot of current MariaDB settings for before/after comparison
# Usage: take_snapshot [label]
#------------------------------------------------------------------------------
take_snapshot() {
    local LABEL="${1:-$(date +%Y%m%d_%H%M%S)}"
    local SNAP_FILE="${TOOLKIT_SNAPSHOT_DIR}/snapshot_${LABEL}.txt"

    header "TAKING SETTINGS SNAPSHOT: ${LABEL}"
    log_info "Taking snapshot: ${LABEL} -> ${SNAP_FILE}"

    if ! command -v mariadb &>/dev/null && ! command -v mysql &>/dev/null; then
        error "MariaDB client not installed. Cannot take snapshot."
        return 1
    fi

    # Check if MariaDB is running
    if ! mariadb -e "SELECT 1;" &>/dev/null 2>&1; then
        error "MariaDB is not running or not accessible. Cannot take snapshot."
        return 1
    fi

    {
        echo "# MariaDB Settings Snapshot"
        echo "# Label: ${LABEL}"
        echo "# Date: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "# MariaDB Version: $(mariadb -N -e 'SELECT VERSION();' 2>/dev/null)"
        echo "# ============================================="
        echo ""
        echo "## Global Variables"
        mariadb -N -e "SHOW GLOBAL VARIABLES;" 2>/dev/null | sort
        echo ""
        echo "## Global Status"
        mariadb -N -e "SHOW GLOBAL STATUS;" 2>/dev/null | sort
        echo ""
        echo "## Database List"
        mariadb -N -e "
            SELECT table_schema, COUNT(*) AS tables,
                   ROUND(SUM(data_length + index_length)/1024/1024, 2) AS size_mb
            FROM information_schema.tables
            WHERE table_schema NOT IN ('information_schema','performance_schema','mysql','sys')
            GROUP BY table_schema
            ORDER BY size_mb DESC;" 2>/dev/null
        echo ""
        echo "## Config File Contents"
        if [ -f "$CNF_TARGET_FILE" ]; then
            echo "# File: ${CNF_TARGET_FILE}"
            cat "$CNF_TARGET_FILE"
        else
            echo "# Config file not found: ${CNF_TARGET_FILE}"
        fi
    } > "$SNAP_FILE"

    success "Snapshot saved: ${SNAP_FILE}"
    info "File size: $(du -h "$SNAP_FILE" | awk '{print $1}')"
    log_success "Snapshot saved to ${SNAP_FILE}"
}

#------------------------------------------------------------------------------
# FUNCTION: compare_snapshots
# Compares two snapshots showing differences (before/after)
# Usage: compare_snapshots <before_label> <after_label>
#------------------------------------------------------------------------------
compare_snapshots() {
    local BEFORE_LABEL="$1"
    local AFTER_LABEL="$2"

    if [ -z "$BEFORE_LABEL" ] || [ -z "$AFTER_LABEL" ]; then
        error "Usage: $0 compare <before_label> <after_label>"
        echo ""
        echo "Available snapshots:"
        ls -la "${TOOLKIT_SNAPSHOT_DIR}"/snapshot_*.txt 2>/dev/null | awk '{print "  " $NF}' || echo "  (none)"
        return 1
    fi

    local BEFORE_FILE="${TOOLKIT_SNAPSHOT_DIR}/snapshot_${BEFORE_LABEL}.txt"
    local AFTER_FILE="${TOOLKIT_SNAPSHOT_DIR}/snapshot_${AFTER_LABEL}.txt"
    local DIFF_FILE="${TOOLKIT_SNAPSHOT_DIR}/diff_${BEFORE_LABEL}_vs_${AFTER_LABEL}.txt"

    if [ ! -f "$BEFORE_FILE" ]; then
        error "Before snapshot not found: ${BEFORE_FILE}"
        return 1
    fi
    if [ ! -f "$AFTER_FILE" ]; then
        error "After snapshot not found: ${AFTER_FILE}"
        return 1
    fi

    header "COMPARING SNAPSHOTS: ${BEFORE_LABEL} vs ${AFTER_LABEL}"
    log_info "Comparing snapshots: ${BEFORE_LABEL} vs ${AFTER_LABEL}"

    # Extract only Global Variables section for comparison
    local BEFORE_VARS=$(sed -n '/^## Global Variables$/,/^## /{ /^## Global Variables$/d; /^## /d; p; }' "$BEFORE_FILE")
    local AFTER_VARS=$(sed -n '/^## Global Variables$/,/^## /{ /^## Global Variables$/d; /^## /d; p; }' "$AFTER_FILE")

    {
        echo "# Snapshot Comparison Report"
        echo "# Before: ${BEFORE_LABEL}"
        echo "# After:  ${AFTER_LABEL}"
        echo "# Date:   $(date '+%Y-%m-%d %H:%M:%S')"
        echo "# ============================================="
        echo ""
        echo "## Changed Global Variables"
        echo ""
    } > "$DIFF_FILE"

    # Compare variable by variable
    local CHANGES=0
    while IFS=$'\t' read -r var_name before_val; do
        local after_val
        after_val=$(echo "$AFTER_VARS" | grep "^${var_name}"$'\t' | cut -f2)
        if [ -n "$after_val" ] && [ "$before_val" != "$after_val" ]; then
            echo "  ${var_name}:" | tee -a "$DIFF_FILE"
            echo "    BEFORE: ${before_val}" | tee -a "$DIFF_FILE"
            echo "    AFTER:  ${after_val}" | tee -a "$DIFF_FILE"
            echo "" | tee -a "$DIFF_FILE"
            CHANGES=$((CHANGES + 1))
        fi
    done <<< "$BEFORE_VARS"

    if [ $CHANGES -eq 0 ]; then
        echo "  No changes detected in global variables." | tee -a "$DIFF_FILE"
    else
        echo "  Total changed variables: ${CHANGES}" | tee -a "$DIFF_FILE"
    fi

    success "Comparison saved: ${DIFF_FILE}"
    info "Total changes: ${CHANGES}"
    log_success "Comparison complete: ${CHANGES} changes found"
}

#------------------------------------------------------------------------------
# FUNCTION: list_snapshots
# Lists all available snapshots
#------------------------------------------------------------------------------
list_snapshots() {
    header "AVAILABLE SNAPSHOTS"
    if ls "${TOOLKIT_SNAPSHOT_DIR}"/snapshot_*.txt &>/dev/null 2>&1; then
        echo -e "${BOLD}Snapshots:${NC}"
        for f in "${TOOLKIT_SNAPSHOT_DIR}"/snapshot_*.txt; do
            local label
            label=$(basename "$f" | sed 's/snapshot_//; s/\.txt//')
            local date_line
            date_line=$(grep "^# Date:" "$f" | head -1 | sed 's/# Date: //')
            local version_line
            version_line=$(grep "^# MariaDB Version:" "$f" | head -1 | sed 's/# MariaDB Version: //')
            printf "  %-30s  %s  (%s)\n" "$label" "$date_line" "$version_line"
        done
        echo ""
        echo -e "${BOLD}Comparison Reports:${NC}"
        if ls "${TOOLKIT_SNAPSHOT_DIR}"/diff_*.txt &>/dev/null 2>&1; then
            for f in "${TOOLKIT_SNAPSHOT_DIR}"/diff_*.txt; do
                echo "  $(basename "$f")"
            done
        else
            echo "  (none)"
        fi
    else
        echo "  No snapshots found in ${TOOLKIT_SNAPSHOT_DIR}/"
        echo "  Take a snapshot with: $0 snapshot <label>"
    fi
}

#------------------------------------------------------------------------------
# FUNCTION: check_resources
#------------------------------------------------------------------------------
check_resources() {
    header "SYSTEM RESOURCE CHECK"
    log_info "Running system resource check"

    # --- RAM ---
    TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    FREE_RAM_KB=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
    TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
    FREE_RAM_MB=$((FREE_RAM_KB / 1024))
    TOTAL_RAM_GB=$(awk "BEGIN {printf \"%.1f\", $TOTAL_RAM_MB/1024}")
    FREE_RAM_GB=$(awk "BEGIN {printf \"%.1f\", $FREE_RAM_MB/1024}")

    echo -e "${BOLD}Memory:${NC}"
    echo -e "  Total RAM:     ${GREEN}${TOTAL_RAM_GB} GB${NC} (${TOTAL_RAM_MB} MB)"
    echo -e "  Available RAM: ${GREEN}${FREE_RAM_GB} GB${NC} (${FREE_RAM_MB} MB)"
    echo ""

    # --- CPU ---
    CPU_CORES=$(nproc)
    CPU_MODEL=$(grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2 | xargs)
    echo -e "${BOLD}CPU:${NC}"
    echo -e "  Cores:  ${GREEN}${CPU_CORES}${NC}"
    echo -e "  Model:  ${CPU_MODEL}"
    echo ""

    # --- Disk ---
    DISK_TOTAL=$(df -h / | tail -1 | awk '{print $2}')
    DISK_USED=$(df -h / | tail -1 | awk '{print $3}')
    DISK_AVAIL=$(df -h / | tail -1 | awk '{print $4}')
    DISK_PCT=$(df -h / | tail -1 | awk '{print $5}')
    echo -e "${BOLD}Disk (root partition):${NC}"
    echo -e "  Total:     ${GREEN}${DISK_TOTAL}${NC}"
    echo -e "  Used:      ${DISK_USED} (${DISK_PCT})"
    echo -e "  Available: ${GREEN}${DISK_AVAIL}${NC}"
    echo ""

    # --- Calculate optimal MariaDB settings ---
    BUFFER_POOL_GB=$((TOTAL_RAM_MB * 65 / 100 / 1024))
    if [ $BUFFER_POOL_GB -lt 1 ]; then BUFFER_POOL_GB=1; fi

    header "OPTIMAL MariaDB SETTINGS (calculated for this system)"
    echo -e "  ${BOLD}InnoDB Core:${NC}"
    echo -e "  innodb_buffer_pool_size      = ${GREEN}${BUFFER_POOL_GB}G${NC}     (65% of ${TOTAL_RAM_GB}GB RAM)"
    echo -e "  innodb_buffer_pool_instances = ${GREEN}${CPU_CORES}${NC}      (one per CPU core)"
    echo -e "  innodb_log_file_size         = ${GREEN}1G${NC}"
    echo -e "  innodb_log_buffer_size       = ${GREEN}256M${NC}"
    echo -e "  innodb_flush_log_at_trx_commit = ${GREEN}2${NC}"
    echo -e "  innodb_io_capacity           = ${GREEN}2000${NC}    (SSD-optimized)"
    echo ""
    echo -e "  ${BOLD}Query Cache:${NC}"
    echo -e "  query_cache_type             = ${GREEN}1 (ON)${NC}"
    echo -e "  query_cache_size             = ${GREEN}256M${NC}"
    echo ""
    echo -e "  ${BOLD}Connections & Timeouts:${NC}"
    echo -e "  max_connections              = ${GREEN}200${NC}"
    echo -e "  max_allowed_packet           = ${GREEN}1G${NC}"
    echo -e "  wait_timeout                 = ${GREEN}86400${NC}   (24 hours)"
    echo ""

    log_info "Resource check complete: ${TOTAL_RAM_GB}GB RAM, ${CPU_CORES} cores"

    # --- MariaDB status ---
    header "MariaDB SERVICE STATUS"
    if command -v mariadb &> /dev/null || command -v mysql &> /dev/null; then
        success "MariaDB client is installed"
        if systemctl is-active --quiet mariadb 2>/dev/null; then
            success "MariaDB service is RUNNING"
            VERSION=$(mariadb --version 2>/dev/null || mysql --version 2>/dev/null)
            echo -e "  Version: ${VERSION}"
        else
            warn "MariaDB is installed but NOT running"
        fi
    else
        warn "MariaDB is NOT installed"
    fi
    echo ""
}

#------------------------------------------------------------------------------
# FUNCTION: install_mariadb
#------------------------------------------------------------------------------
install_mariadb() {
    header "INSTALLING MariaDB"
    log_info "Starting MariaDB installation"

    if command -v mariadb &> /dev/null; then
        success "MariaDB is already installed"
        mariadb --version
        log_info "MariaDB already installed"
    else
        info "Updating package list..."
        apt-get update -qq
        info "Installing mariadb-server and mariadb-client..."
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq mariadb-server mariadb-client pv
        success "MariaDB installed successfully"
        log_success "MariaDB installed"
    fi

    # Start and enable service
    info "Starting MariaDB service..."
    if systemctl start mariadb 2>/dev/null; then
        systemctl enable mariadb 2>/dev/null || true
        success "MariaDB service started and enabled"
        log_success "MariaDB service started"
    elif systemctl start mysql 2>/dev/null; then
        systemctl enable mysql 2>/dev/null || true
        success "MariaDB service started (as mysql unit)"
    else
        warn "systemctl not available, starting mysqld directly..."
        mysqld_safe &
        sleep 3
        if pgrep -x mysqld > /dev/null; then
            success "MariaDB started manually"
        else
            error "Failed to start MariaDB"
            return 1
        fi
    fi
}

#------------------------------------------------------------------------------
# FUNCTION: configure_mariadb
# Takes automatic before/after snapshots
#------------------------------------------------------------------------------
configure_mariadb() {
    header "CONFIGURING MariaDB FOR MAXIMUM PERFORMANCE"
    log_info "Starting MariaDB configuration"

    # Take BEFORE snapshot automatically
    if mariadb -e "SELECT 1;" &>/dev/null 2>&1; then
        info "Taking BEFORE configuration snapshot..."
        take_snapshot "before_configure_$(date +%Y%m%d_%H%M%S)"
    fi

    # --- Detect system resources ---
    TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
    TOTAL_RAM_GB=$((TOTAL_RAM_MB / 1024))
    CPU_CORES=$(nproc)

    BUFFER_POOL_GB=$((TOTAL_RAM_GB * 65 / 100))
    if [ $BUFFER_POOL_GB -lt 1 ]; then BUFFER_POOL_GB=1; fi
    POOL_INSTANCES=$CPU_CORES
    if [ $POOL_INSTANCES -gt 64 ]; then POOL_INSTANCES=64; fi

    info "System: ${TOTAL_RAM_GB}GB RAM, ${CPU_CORES} CPU cores"
    info "Calculated buffer pool: ${BUFFER_POOL_GB}GB (65% of RAM)"

    # --- Ensure config directory exists ---
    mkdir -p "$CNF_TARGET_DIR"

    # --- Check for master config file ---
    if [ -f "$TOOLKIT_PERF_CNF" ]; then
        info "Using performance config: $TOOLKIT_PERF_CNF"
        cp "$TOOLKIT_PERF_CNF" "$CNF_TARGET_FILE"
        success "Configuration copied to ${CNF_TARGET_FILE}"
        log_success "Config copied from ${TOOLKIT_PERF_CNF} to ${CNF_TARGET_FILE}"
    else
        info "Performance .cnf not found at ${TOOLKIT_PERF_CNF}, generating config..."
        cat > "$CNF_TARGET_FILE" << EOF
# =============================================================================
# MariaDB Advanced Performance Configuration
# Auto-generated by mariadb_toolkit.sh v2 on $(date '+%Y-%m-%d %H:%M:%S')
# Server: ${TOTAL_RAM_GB}GB RAM, ${CPU_CORES} CPU Cores
# =============================================================================

[mysqld]
innodb_buffer_pool_size = ${BUFFER_POOL_GB}G
innodb_buffer_pool_instances = ${POOL_INSTANCES}
innodb_log_file_size = 1G
innodb_log_buffer_size = 256M
innodb_flush_log_at_trx_commit = 2
innodb_flush_method = O_DIRECT
innodb_file_per_table = 1
innodb_read_io_threads = ${CPU_CORES}
innodb_write_io_threads = ${CPU_CORES}
innodb_io_capacity = 2000
innodb_io_capacity_max = 4000
innodb_purge_threads = 4
innodb_open_files = 4000
innodb_buffer_pool_dump_at_shutdown = ON
innodb_buffer_pool_load_at_startup = ON
innodb_buffer_pool_dump_pct = 75
innodb_adaptive_hash_index = OFF
innodb_stats_persistent = ON
innodb_print_all_deadlocks = ON
query_cache_type = 1
query_cache_size = 256M
query_cache_limit = 8M
thread_cache_size = 100
thread_pool_size = ${CPU_CORES}
max_connections = 200
max_allowed_packet = 1G
wait_timeout = 86400
interactive_timeout = 86400
net_read_timeout = 7200
net_write_timeout = 7200
table_open_cache = 4000
table_open_cache_instances = ${CPU_CORES}
table_definition_cache = 2000
sort_buffer_size = 8M
join_buffer_size = 8M
read_buffer_size = 4M
read_rnd_buffer_size = 8M
bulk_insert_buffer_size = 64M
tmp_table_size = 512M
max_heap_table_size = 512M
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2
log_queries_not_using_indexes = ON
aria_pagecache_buffer_size = 256M
key_buffer_size = 256M
performance_schema = ON
character_set_server = utf8mb4
collation_server = utf8mb4_general_ci
max_connect_errors = 1000000
open_files_limit = 65535

[client]
max_allowed_packet = 1G

[mysqldump]
max_allowed_packet = 1G
single-transaction
quick
EOF
        success "Configuration generated and written to ${CNF_TARGET_FILE}"
        log_success "Config generated at ${CNF_TARGET_FILE}"
    fi

    # --- Create slow query log directory ---
    mkdir -p /var/log/mysql
    chown mysql:mysql /var/log/mysql 2>/dev/null || true

    # --- Remove old configs ---
    for old_conf in "99-custom-optimized.cnf"; do
        for dir in /etc/mysql/mariadb.conf.d /etc/mysql/conf.d /etc/my.cnf.d; do
            if [ -f "${dir}/${old_conf}" ]; then
                rm -f "${dir}/${old_conf}"
                info "Removed old config: ${dir}/${old_conf}"
            fi
        done
    done

    # --- Restart MariaDB ---
    info "Restarting MariaDB to apply new configuration..."
    if /etc/init.d/mariadb restart 2>/dev/null; then
        success "MariaDB restarted with new configuration"
    elif systemctl restart mariadb 2>/dev/null || systemctl restart mysql 2>/dev/null; then
        success "MariaDB restarted with new configuration"
    else
        warn "Could not restart via systemctl, trying manual restart..."
        pkill -f mysqld 2>/dev/null || true
        sleep 2
        mysqld_safe &
        sleep 3
        if pgrep -x mariadbd > /dev/null || pgrep -x mysqld > /dev/null; then
            success "MariaDB restarted manually"
        else
            error "Failed to restart MariaDB"
            return 1
        fi
    fi

    sleep 3
    log_success "MariaDB restarted with new configuration"

    # --- Verify key settings ---
    header "VERIFYING APPLIED SETTINGS"
    sudo mysql -u root -e "
        SELECT 'innodb_buffer_pool_size' AS Setting, CONCAT(ROUND(@@innodb_buffer_pool_size/1024/1024/1024,1), ' GB') AS Value
        UNION ALL SELECT 'innodb_buffer_pool_instances', @@innodb_buffer_pool_instances
        UNION ALL SELECT 'innodb_log_file_size', CONCAT(ROUND(@@innodb_log_file_size/1024/1024), ' MB')
        UNION ALL SELECT 'query_cache_size', CONCAT(ROUND(@@query_cache_size/1024/1024), ' MB')
        UNION ALL SELECT 'max_connections', @@max_connections
        UNION ALL SELECT 'max_allowed_packet', CONCAT(ROUND(@@max_allowed_packet/1024/1024), ' MB')
        UNION ALL SELECT 'wait_timeout', @@wait_timeout
        UNION ALL SELECT 'slow_query_log', @@slow_query_log
        UNION ALL SELECT 'long_query_time', @@long_query_time;
    " 2>/dev/null || warn "Could not verify settings"

    # Take AFTER snapshot automatically
    info "Taking AFTER configuration snapshot..."
    take_snapshot "after_configure_$(date +%Y%m%d_%H%M%S)"
}

#------------------------------------------------------------------------------
# FUNCTION: show_performance
#------------------------------------------------------------------------------
show_performance() {
    header "MariaDB PERFORMANCE CONFIGURATION"
    log_info "Showing performance configuration"

    echo -e "${BOLD}InnoDB Settings:${NC}"
    sudo mysql -u root -e "
        SELECT Variable_name, Value
        FROM information_schema.global_variables
        WHERE Variable_name IN (
            'innodb_buffer_pool_size', 'innodb_buffer_pool_instances',
            'innodb_log_file_size', 'innodb_log_buffer_size',
            'innodb_flush_log_at_trx_commit', 'innodb_flush_method',
            'innodb_file_per_table', 'innodb_read_io_threads',
            'innodb_write_io_threads', 'innodb_io_capacity',
            'innodb_io_capacity_max', 'innodb_open_files'
        ) ORDER BY Variable_name;
    " 2>/dev/null
    echo ""

    echo -e "${BOLD}Query Cache:${NC}"
    sudo mysql -u root -e "SHOW VARIABLES LIKE 'query_cache%';" 2>/dev/null
    echo ""

    echo -e "${BOLD}Connection & Timeout:${NC}"
    sudo mysql -u root -e "
        SELECT Variable_name, Value
        FROM information_schema.global_variables
        WHERE Variable_name IN (
            'max_connections', 'max_allowed_packet',
            'wait_timeout', 'interactive_timeout',
            'net_read_timeout', 'net_write_timeout',
            'thread_cache_size', 'thread_pool_size'
        ) ORDER BY Variable_name;
    " 2>/dev/null
    echo ""

    echo -e "${BOLD}Buffer Settings (per session):${NC}"
    sudo mysql -u root -e "
        SELECT Variable_name, Value
        FROM information_schema.global_variables
        WHERE Variable_name IN (
            'sort_buffer_size', 'join_buffer_size',
            'read_buffer_size', 'read_rnd_buffer_size',
            'bulk_insert_buffer_size', 'tmp_table_size',
            'max_heap_table_size'
        ) ORDER BY Variable_name;
    " 2>/dev/null
    echo ""

    echo -e "${BOLD}Slow Query Log:${NC}"
    sudo mysql -u root -e "
        SELECT Variable_name, Value
        FROM information_schema.global_variables
        WHERE Variable_name IN (
            'slow_query_log', 'slow_query_log_file',
            'long_query_time', 'log_queries_not_using_indexes'
        ) ORDER BY Variable_name;
    " 2>/dev/null
    echo ""

    echo -e "${BOLD}Memory Budget:${NC}"
    POOL=$(sudo mysql -u root -N -e "SELECT ROUND(@@innodb_buffer_pool_size/1024/1024/1024,1);" 2>/dev/null)
    LOG_BUF=$(sudo mysql -u root -N -e "SELECT ROUND(@@innodb_log_buffer_size/1024/1024);" 2>/dev/null)
    QC=$(sudo mysql -u root -N -e "SELECT ROUND(@@query_cache_size/1024/1024);" 2>/dev/null)
    echo -e "  InnoDB Buffer Pool:  ${GREEN}${POOL} GB${NC}"
    echo -e "  InnoDB Log Buffer:   ${GREEN}${LOG_BUF} MB${NC}"
    echo -e "  Query Cache:         ${GREEN}${QC} MB${NC}"
    echo -e "  Config file:         ${CNF_TARGET_FILE}"
    echo -e "  Master config:       ${TOOLKIT_PERF_CNF}"
}

#------------------------------------------------------------------------------
# FUNCTION: full_setup
#------------------------------------------------------------------------------
full_setup() {
    log_info "Starting full setup"
    install_mariadb
    configure_mariadb
    header "SETUP COMPLETE"
    success "MariaDB is installed and configured for optimal performance."
    log_success "Full setup complete"
    echo ""
    echo -e "${BOLD}Quick Reference:${NC}"
    echo -e "  Import a dump:  ${CYAN}bash $0 import /path/to/dump.sql database_name${NC}"
    echo -e "  Export a dump:  ${CYAN}bash $0 export database_name /path/to/output.sql${NC}"
    echo -e "  List databases: ${CYAN}bash $0 list${NC}"
    echo -e "  DB statistics:  ${CYAN}bash $0 stats database_name${NC}"
}

#------------------------------------------------------------------------------
# FUNCTION: import_dump
#------------------------------------------------------------------------------
import_dump() {
    local SQL_FILE="$1"
    local DB_NAME="$2"

    if [ -z "$SQL_FILE" ] || [ -z "$DB_NAME" ]; then
        error "Usage: $0 import <sql_file> <database_name>"
        echo -e "  Example: ${CYAN}bash $0 import /path/to/dump.sql mydb${NC}"
        return 1
    fi

    if [ ! -f "$SQL_FILE" ]; then
        error "SQL file not found: $SQL_FILE"
        return 1
    fi

    local FILE_SIZE=$(du -h "$SQL_FILE" | awk '{print $1}')
    header "IMPORTING SQL DUMP"
    info "File:     $SQL_FILE ($FILE_SIZE)"
    info "Database: $DB_NAME"
    log_info "Importing ${SQL_FILE} (${FILE_SIZE}) into database ${DB_NAME}"

    info "Creating database '$DB_NAME' if it doesn't exist..."
    mariadb -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
    success "Database '$DB_NAME' ready"

    info "Starting import (this may take several minutes for large files)..."
    local START_TIME=$(date +%s)

    if command -v pv &> /dev/null; then
        pv "$SQL_FILE" | mariadb "$DB_NAME"
    else
        mariadb "$DB_NAME" < "$SQL_FILE"
    fi

    local END_TIME=$(date +%s)
    local DURATION=$((END_TIME - START_TIME))
    local MINUTES=$((DURATION / 60))
    local SECONDS=$((DURATION % 60))

    success "Import completed in ${MINUTES}m ${SECONDS}s"
    log_success "Import of ${SQL_FILE} into ${DB_NAME} completed in ${MINUTES}m ${SECONDS}s"

    local TABLE_COUNT=$(mariadb -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$DB_NAME' AND table_type='BASE TABLE';")
    info "Tables in '$DB_NAME': $TABLE_COUNT"
}

#------------------------------------------------------------------------------
# FUNCTION: export_dump
#------------------------------------------------------------------------------
export_dump() {
    local DB_NAME="$1"
    local OUTPUT_FILE="$2"

    if [ -z "$DB_NAME" ]; then
        error "Usage: $0 export <database_name> [output_file]"
        return 1
    fi

    if [ -z "$OUTPUT_FILE" ]; then
        OUTPUT_FILE="${SCRIPT_DIR}/${DB_NAME}_$(date +%Y%m%d_%H%M%S).sql"
    fi

    if ! mariadb -N -e "SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='$DB_NAME';" | grep -q "$DB_NAME"; then
        error "Database '$DB_NAME' does not exist"
        list_databases
        return 1
    fi

    header "EXPORTING DATABASE"
    info "Database: $DB_NAME"
    info "Output:   $OUTPUT_FILE"
    log_info "Exporting database ${DB_NAME} to ${OUTPUT_FILE}"

    mkdir -p "$(dirname "$OUTPUT_FILE")"

    local START_TIME=$(date +%s)

    mysqldump \
        --single-transaction \
        --routines \
        --triggers \
        --events \
        --quick \
        --add-drop-table \
        --set-charset \
        --default-character-set=utf8mb4 \
        "$DB_NAME" > "$OUTPUT_FILE"

    local END_TIME=$(date +%s)
    local DURATION=$((END_TIME - START_TIME))
    local FILE_SIZE=$(du -h "$OUTPUT_FILE" | awk '{print $1}')

    success "Export completed in ${DURATION}s"
    info "Output file: $OUTPUT_FILE ($FILE_SIZE)"
    log_success "Export of ${DB_NAME} to ${OUTPUT_FILE} (${FILE_SIZE}) completed in ${DURATION}s"
}

#------------------------------------------------------------------------------
# FUNCTION: list_databases
#------------------------------------------------------------------------------
list_databases() {
    header "DATABASE LIST"
    log_info "Listing databases"
    mariadb -e "
        SELECT 
            table_schema AS 'Database',
            COUNT(*) AS 'Tables',
            ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size_MB',
            ROUND(SUM(data_length) / 1024 / 1024, 2) AS 'Data_MB',
            ROUND(SUM(index_length) / 1024 / 1024, 2) AS 'Index_MB'
        FROM information_schema.tables
        WHERE table_schema NOT IN ('information_schema', 'performance_schema', 'mysql', 'sys')
        GROUP BY table_schema
        ORDER BY SUM(data_length + index_length) DESC;
    " 2>/dev/null || warn "Could not list databases"
}

#------------------------------------------------------------------------------
# FUNCTION: db_stats
#------------------------------------------------------------------------------
db_stats() {
    local DB_NAME="$1"

    if [ -z "$DB_NAME" ]; then
        list_databases
        return
    fi

    header "DATABASE STATISTICS: $DB_NAME"
    log_info "Showing stats for database: ${DB_NAME}"

    echo -e "${BOLD}Overview:${NC}"
    mariadb -e "
        SELECT 
            COUNT(*) AS 'Total_Tables',
            SUM(table_rows) AS 'Total_Rows_Approx',
            ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Total_Size_MB',
            ROUND(SUM(data_length) / 1024 / 1024, 2) AS 'Data_MB',
            ROUND(SUM(index_length) / 1024 / 1024, 2) AS 'Index_MB'
        FROM information_schema.tables
        WHERE table_schema = '$DB_NAME' AND table_type = 'BASE TABLE';
    "
    echo ""

    echo -e "${BOLD}Top 20 Largest Tables:${NC}"
    mariadb -e "
        SELECT 
            table_name AS 'Table_Name',
            table_rows AS 'Rows',
            ROUND(data_length / 1024 / 1024, 2) AS 'Data_MB',
            ROUND(index_length / 1024 / 1024, 2) AS 'Index_MB',
            ROUND((data_length + index_length) / 1024 / 1024, 2) AS 'Total_MB'
        FROM information_schema.tables
        WHERE table_schema = '$DB_NAME' AND table_type = 'BASE TABLE'
        ORDER BY (data_length + index_length) DESC
        LIMIT 20;
    "
    echo ""

    echo -e "${BOLD}Stored Routines & Triggers:${NC}"
    mariadb -e "
        SELECT 
            (SELECT COUNT(*) FROM information_schema.triggers WHERE trigger_schema='$DB_NAME') AS 'Triggers',
            (SELECT COUNT(*) FROM information_schema.routines WHERE routine_schema='$DB_NAME' AND routine_type='PROCEDURE') AS 'Procedures',
            (SELECT COUNT(*) FROM information_schema.routines WHERE routine_schema='$DB_NAME' AND routine_type='FUNCTION') AS 'Functions',
            (SELECT COUNT(*) FROM information_schema.views WHERE table_schema='$DB_NAME') AS 'Views';
    "
}

#------------------------------------------------------------------------------
# FUNCTION: show_status
#------------------------------------------------------------------------------
show_status() {
    header "MariaDB SERVICE STATUS"
    log_info "Checking MariaDB status"

    if systemctl is-active --quiet mariadb 2>/dev/null; then
        success "MariaDB is RUNNING"
    elif systemctl is-active --quiet mysql 2>/dev/null; then
        success "MariaDB is RUNNING (as mysql unit)"
    elif pgrep -x mysqld > /dev/null 2>/dev/null; then
        success "MariaDB is RUNNING (standalone)"
    else
        error "MariaDB is NOT running"
        return 1
    fi

    mariadb -e "SELECT VERSION() AS 'Version';" 2>/dev/null
    echo ""
    echo -e "${BOLD}Key Variables:${NC}"
    mariadb -e "
        SELECT 'max_allowed_packet' AS Variable, CONCAT(@@max_allowed_packet/1024/1024, ' MB') AS Value
        UNION ALL SELECT 'innodb_buffer_pool_size', CONCAT(@@innodb_buffer_pool_size/1024/1024, ' MB')
        UNION ALL SELECT 'wait_timeout', @@wait_timeout
        UNION ALL SELECT 'interactive_timeout', @@interactive_timeout
        UNION ALL SELECT 'max_connections', @@max_connections;
    " 2>/dev/null
}

#------------------------------------------------------------------------------
# FUNCTION: restart_service
#------------------------------------------------------------------------------
restart_service() {
    header "RESTARTING MariaDB"
    log_info "Restarting MariaDB service"
    if systemctl restart mariadb 2>/dev/null || systemctl restart mysql 2>/dev/null; then
        success "MariaDB restarted successfully"
        log_success "MariaDB restarted"
    else
        warn "systemctl failed, trying manual restart..."
        pkill -f mysqld 2>/dev/null || true
        sleep 2
        mysqld_safe &
        sleep 3
        if pgrep -x mysqld > /dev/null; then
            success "MariaDB restarted"
        else
            error "Failed to restart"
        fi
    fi
}

#------------------------------------------------------------------------------
# FUNCTION: show_help
#------------------------------------------------------------------------------
show_help() {
    echo -e "${BOLD}${CYAN}MariaDB Toolkit v2 - Setup & Management Script${NC}"
    echo ""
    echo -e "${BOLD}Usage:${NC} bash $0 <command> [arguments]"
    echo ""
    echo -e "${BOLD}Commands:${NC}"
    echo -e "  ${GREEN}check${NC}                                Check system resources"
    echo -e "  ${GREEN}install${NC}                              Install MariaDB"
    echo -e "  ${GREEN}configure${NC}                            Apply optimized configuration (auto-snapshots)"
    echo -e "  ${GREEN}setup${NC}                                Full setup (install + configure)"
    echo -e "  ${GREEN}import${NC} <sql_file> <db_name>          Import SQL dump into database"
    echo -e "  ${GREEN}export${NC} <db_name> [output_file]       Export database to SQL dump"
    echo -e "  ${GREEN}list${NC}                                 List all databases with sizes"
    echo -e "  ${GREEN}stats${NC} [db_name]                      Show database statistics"
    echo -e "  ${GREEN}status${NC}                               Show MariaDB service status"
    echo -e "  ${GREEN}restart${NC}                              Restart MariaDB service"
    echo -e "  ${GREEN}performance${NC}                          Show current performance config"
    echo -e "  ${GREEN}snapshot${NC} [label]                     Take a settings snapshot"
    echo -e "  ${GREEN}compare${NC} <before> <after>             Compare two snapshots"
    echo -e "  ${GREEN}snapshots${NC}                            List all available snapshots"
    echo -e "  ${GREEN}help${NC}                                 Show this help message"
    echo ""
    echo -e "${BOLD}Examples:${NC}"
    echo -e "  bash $0 check"
    echo -e "  bash $0 setup"
    echo -e "  bash $0 import /path/to/dump.sql mydb"
    echo -e "  bash $0 snapshot before_tuning"
    echo -e "  bash $0 configure"
    echo -e "  bash $0 snapshot after_tuning"
    echo -e "  bash $0 compare before_tuning after_tuning"
    echo ""
    echo -e "${BOLD}Environment Variables:${NC}"
    echo -e "  TOOLKIT_LOG_DIR       Log directory (current: ${TOOLKIT_LOG_DIR})"
    echo -e "  TOOLKIT_PERF_CNF      Performance .cnf path (current: ${TOOLKIT_PERF_CNF})"
    echo -e "  TOOLKIT_SNAPSHOT_DIR  Snapshot directory (current: ${TOOLKIT_SNAPSHOT_DIR})"
    echo -e "  TOOLKIT_CNF_DIR       MariaDB config directory (current: ${CNF_TARGET_DIR})"
    echo ""
    echo -e "${BOLD}Log file:${NC} ${LOG_FILE}"
}

#==============================================================================
# MAIN: Command dispatcher
#==============================================================================
case "${1:-help}" in
    check)      check_resources ;;
    install)    install_mariadb ;;
    configure)  configure_mariadb ;;
    setup)      full_setup ;;
    import)     import_dump "$2" "$3" ;;
    export)     export_dump "$2" "$3" ;;
    list)       list_databases ;;
    stats)      db_stats "$2" ;;
    status)     show_status ;;
    restart)    restart_service ;;
    performance|perf) show_performance ;;
    snapshot)   take_snapshot "$2" ;;
    compare)    compare_snapshots "$2" "$3" ;;
    snapshots)  list_snapshots ;;
    help|--help|-h) show_help ;;
    *)
        error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac

log_info "Toolkit command '$1' completed"
