#!/bin/bash
#==============================================================================
# MariaDB Quick Setup Script v2
# One-command install, configure, and start MariaDB with performance tuning
#
# Usage: sudo bash quick_setup.sh
#
# v2: All paths parameterized, automatic logging, before/after snapshots
#==============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOLKIT="${SCRIPT_DIR}/mariadb_toolkit.sh"
PERF_CNF="${TOOLKIT_PERF_CNF:-${SCRIPT_DIR}/mariadb_performance.cnf}"

# Auto-detect MariaDB config directory
if [ -n "$TOOLKIT_CNF_DIR" ]; then
    TARGET_CNF="${TOOLKIT_CNF_DIR}/99-performance.cnf"
elif [ -d /etc/mysql/mariadb.conf.d ]; then
    TARGET_CNF="/etc/mysql/mariadb.conf.d/99-performance.cnf"
elif [ -d /etc/mysql/conf.d ]; then
    TARGET_CNF="/etc/mysql/conf.d/99-performance.cnf"
elif [ -d /etc/my.cnf.d ]; then
    TARGET_CNF="/etc/my.cnf.d/99-performance.cnf"
else
    TARGET_CNF="/etc/mysql/mariadb.conf.d/99-performance.cnf"
fi

# Logging
LOG_DIR="${TOOLKIT_LOG_DIR:-${SCRIPT_DIR}/logs}"
mkdir -p "$LOG_DIR"
LOG_FILE="${LOG_DIR}/quick_setup_$(date +%Y%m%d).log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${BLUE}  MariaDB Quick Setup v2 - Install, Configure & Start${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo ""

log "Quick setup started"
log "Script dir: ${SCRIPT_DIR}"
log "Perf CNF: ${PERF_CNF}"
log "Target CNF: ${TARGET_CNF}"

# Check root
if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}ERROR: This script must be run as root (use sudo)${NC}"
    log "ERROR: Not running as root"
    exit 1
fi

# Check required files exist
if [[ ! -f "$TOOLKIT" ]]; then
    echo -e "${RED}ERROR: mariadb_toolkit.sh not found at: $TOOLKIT${NC}"
    log "ERROR: mariadb_toolkit.sh not found"
    exit 1
fi

if [[ ! -f "$PERF_CNF" ]]; then
    echo -e "${RED}ERROR: mariadb_performance.cnf not found at: $PERF_CNF${NC}"
    log "ERROR: mariadb_performance.cnf not found"
    exit 1
fi

#------------------------------------------------------------------------------
# STEP 1: Install MariaDB
#------------------------------------------------------------------------------
echo -e "${YELLOW}[Step 1/5] Checking MariaDB installation...${NC}"
log "Step 1: Checking MariaDB installation"

if command -v mariadb &>/dev/null; then
    echo -e "${GREEN}  ✓ MariaDB is already installed $(mariadb --version 2>/dev/null | head -1)${NC}"
    log "MariaDB already installed"
else
    echo -e "  Installing MariaDB server & client..."
    apt-get update -qq
    apt-get install -y -qq mariadb-server mariadb-client pv
    echo -e "${GREEN}  ✓ MariaDB installed successfully${NC}"
    log "MariaDB installed"
fi

#------------------------------------------------------------------------------
# STEP 2: Take BEFORE snapshot (if MariaDB is running)
#------------------------------------------------------------------------------
echo -e "${YELLOW}[Step 2/5] Taking BEFORE snapshot...${NC}"
log "Step 2: Taking before snapshot"

if systemctl is-active --quiet mariadb 2>/dev/null || pgrep -x mysqld &>/dev/null; then
    bash "$TOOLKIT" snapshot "before_quicksetup_$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
    echo -e "${GREEN}  ✓ Before snapshot saved${NC}"
else
    echo -e "${YELLOW}  ⊘ MariaDB not yet running, skipping before snapshot${NC}"
fi

#------------------------------------------------------------------------------
# STEP 3: Apply Performance Configuration
#------------------------------------------------------------------------------
echo -e "${YELLOW}[Step 3/5] Applying performance configuration...${NC}"
log "Step 3: Applying performance config"

mkdir -p "$(dirname "$TARGET_CNF")"
cp "$PERF_CNF" "$TARGET_CNF"
chmod 644 "$TARGET_CNF"
echo -e "${GREEN}  ✓ Configuration copied to $TARGET_CNF${NC}"
log "Config copied to $TARGET_CNF"

mkdir -p /var/log/mysql
chown mysql:mysql /var/log/mysql 2>/dev/null || chown mysql:adm /var/log/mysql 2>/dev/null || true

#------------------------------------------------------------------------------
# STEP 4: Start/Restart MariaDB
#------------------------------------------------------------------------------
echo -e "${YELLOW}[Step 4/5] Starting MariaDB service...${NC}"
log "Step 4: Starting/restarting MariaDB"

if systemctl is-active --quiet mariadb 2>/dev/null; then
    echo "  MariaDB is running, restarting to apply new config..."
    systemctl restart mariadb
else
    echo "  Starting MariaDB service..."
    systemctl start mariadb 2>/dev/null || mysqld_safe &
    sleep 2
fi

if systemctl is-active --quiet mariadb 2>/dev/null; then
    echo -e "${GREEN}  ✓ MariaDB is running${NC}"
    log "MariaDB started/restarted successfully"
else
    echo -e "${RED}  ✗ MariaDB failed to start. Check: journalctl -xe${NC}"
    log "ERROR: MariaDB failed to start"
    exit 1
fi

#------------------------------------------------------------------------------
# STEP 5: Verify and take AFTER snapshot
#------------------------------------------------------------------------------
echo -e "${YELLOW}[Step 5/5] Verifying and taking AFTER snapshot...${NC}"
log "Step 5: Verifying and taking after snapshot"
echo ""

declare -A SETTINGS=(
    ["innodb_buffer_pool_size"]="~40GB"
    ["max_allowed_packet"]="~1GB"
    ["wait_timeout"]="86400"
    ["query_cache_size"]="~256MB"
    ["innodb_log_file_size"]="~1GB"
    ["max_connections"]="200"
)

echo -e "  ${BLUE}Key Performance Settings:${NC}"
for var in innodb_buffer_pool_size max_allowed_packet wait_timeout query_cache_size innodb_log_file_size max_connections; do
    VALUE=$(mariadb -N -e "SHOW VARIABLES LIKE '$var';" 2>/dev/null | awk '{print $2}')
    if [[ -n "$VALUE" ]]; then
        if [[ "$VALUE" -gt 1073741824 ]] 2>/dev/null; then
            HR=$(echo "scale=1; $VALUE/1073741824" | bc)"GB"
        elif [[ "$VALUE" -gt 1048576 ]] 2>/dev/null; then
            HR=$(echo "scale=0; $VALUE/1048576" | bc)"MB"
        else
            HR="$VALUE"
        fi
        printf "    %-30s = %s\n" "$var" "$HR"
        log "Verified: $var = $HR"
    fi
done

# Take AFTER snapshot
bash "$TOOLKIT" snapshot "after_quicksetup_$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
echo -e "${GREEN}  ✓ After snapshot saved${NC}"

echo ""
echo -e "${GREEN}==============================================================================${NC}"
echo -e "${GREEN}  ✓ MariaDB Quick Setup Complete!${NC}"
echo -e "${GREEN}==============================================================================${NC}"
echo ""
echo -e "  Next steps:"
echo -e "    • Import databases:  sudo bash ${SCRIPT_DIR}/mariadb_toolkit.sh import <dump.sql> <dbname>"
echo -e "    • List databases:    bash ${SCRIPT_DIR}/mariadb_toolkit.sh list"
echo -e "    • Check performance: bash ${SCRIPT_DIR}/mariadb_toolkit.sh performance"
echo -e "    • View snapshots:    bash ${SCRIPT_DIR}/mariadb_toolkit.sh snapshots"
echo -e "    • View logs:         cat ${LOG_FILE}"
echo ""
log "Quick setup completed successfully"
