# Abacus Claw - Tehnička Specifikacija za Meta-Bot

## Izvršni Pregled

Ovaj dokument sadrži kompletnu tehničku specifikaciju za kreiranje Claw agenta koji će služiti kao "domaćin" - centralna tačka komunikacije između korisnika i DeepAgent-a na Abacus.AI platformi.

---

## 1. Šta je Abacus Claw?

**Abacus Claw** je managed, hosted verzija **OpenClaw** - open-source platforme za kreiranje always-on AI agenata koji rade u cloudu.

### Ključne karakteristike:
- **Perzistentna memorija** - Agent pamti kontekst kroz sesije i kanale
- **24/7 operacija** - Radi i kad korisnik nije online
- **Cron poslovi** - Zakazivanje ponavljajućih zadataka
- **Multi-channel prisustvo** - WhatsApp, Telegram, Slack
- **Cloud Computer** - Linux okruženje sa terminalom, browserom i fajl sistemom
- **Tool integracije** - Notion, GitHub, Gmail, Google Calendar, itd.

### Razlika od običnog chatbota:
| Aspekt | Obični Chatbot | Claw Agent |
|--------|----------------|------------|
| Memorija | Reset nakon sesije | Perzistentna |
| Operacija | Samo kad korisnik koristi | 24/7 |
| Kanali | Jedan | Multi-channel |
| Compute | Ograničen | Full Cloud Computer |
| Autonomija | Reaktivan | Proaktivan |

---

## 2. SDK Metode za Agente

### 2.1 Osnovne Agent Metode

```python
import abacusai
client = abacusai.ApiClient()
```

#### create_agent
```python
def create_agent(
    project_id: str,                    # ID projekta (obavezan)
    name: str = None,                   # Ime agenta
    memory: int = None,                 # RAM u MB
    package_requirements: List = [],    # Python paketi
    description: str = None,            # Opis agenta
    evaluation_feature_group_id: str = None,
    workflow_graph: WorkflowGraph = None,   # Graf workflow-a
    agent_interface: AgentInterface = AgentInterface.DEFAULT,  # Tip interfejsa
    included_modules: List[str] = None,     # Uključeni moduli
    org_level_connectors: List[ID] = None,  # Org-level konektori
    user_level_connectors: Dict[ApplicationConnectorType, List[str]] = None,
    initialize_function_name: str = None,
    initialize_function_code: str = None
) -> Agent
```

#### update_agent
```python
def update_agent(
    model_id: str,                      # Agent ID (obavezan)
    memory: int = None,
    package_requirements: List = None,
    description: str = None,
    workflow_graph: WorkflowGraph = None,
    agent_interface: AgentInterface = None,
    included_modules: List[str] = None,
    org_level_connectors: List[ID] = None,
    user_level_connectors: Dict[ApplicationConnectorType, List[str]] = None,
    initialize_function_name: str = None,
    initialize_function_code: str = None
) -> Agent
```

#### describe_agent
```python
agent = client.describe_agent(agent_id)
# Vraća: Agent objekat sa svim detaljima
```

#### list_agents
```python
agents = client.list_agents(project_id)
# Vraća: Lista agenata u projektu
```

### 2.2 AgentInterface Enum

```python
from abacusai import AgentInterface

AgentInterface.DEFAULT     # Standardni agent
AgentInterface.CHAT        # Chat interfejs
AgentInterface.AUTONOMOUS  # Autonomni agent (za Claw)
AgentInterface.MATRIX      # Matrix interfejs
```

### 2.3 ApplicationConnectorType Enum

```python
from abacusai import ApplicationConnectorType

# Dostupni konektori:
ApplicationConnectorType.SLACK
ApplicationConnectorType.GMAILUSER
ApplicationConnectorType.GOOGLECALENDAR
ApplicationConnectorType.GOOGLEDRIVE
ApplicationConnectorType.GOOGLEDRIVEUSER
ApplicationConnectorType.ONEDRIVE
ApplicationConnectorType.OUTLOOK
ApplicationConnectorType.GITHUB
ApplicationConnectorType.GITHUBUSER
ApplicationConnectorType.JIRA
ApplicationConnectorType.CONFLUENCE
ApplicationConnectorType.SALESFORCE
ApplicationConnectorType.SHAREPOINT
ApplicationConnectorType.TEAMS
ApplicationConnectorType.TWITTER
ApplicationConnectorType.BOX
ApplicationConnectorType.ZENDESK
ApplicationConnectorType.MCP
ApplicationConnectorType.GENERIC_OAUTH
# ... i mnogi drugi
```

---

## 3. WorkflowGraph Struktura

### 3.1 Kreiranje WorkflowGraph-a

```python
from abacusai import WorkflowGraph, WorkflowGraphNode

# Struktura WorkflowGraph-a
workflow_graph = WorkflowGraph(
    nodes=[...],                    # Lista WorkflowGraphNode objekata
    edges=[...],                    # Lista edge-ova između node-ova
    primary_start_node='NodeName',  # Ime početnog node-a
    specification_type='data_flow'  # Tip specifikacije
)
```

### 3.2 WorkflowGraphNode Metode

```python
from abacusai import WorkflowGraphNode

# Kreiranje node-a iz template-a
node = WorkflowGraphNode.from_template(
    template_name='llm_node',       # Ime template-a
    name='MyNode',                  # Ime node-a
    configs={...},                  # Konfiguracija
    input_mappings={...},           # Mapiranje ulaza
    input_schema=[...],             # Šema ulaza
    output_schema=[...],            # Šema izlaza
    sleep_time=None                 # Pauza pre izvršavanja
)

# Kreiranje node-a iz tool-a
node = WorkflowGraphNode.from_tool(
    tool_name='web_search',         # Ime alata
    name='SearchNode',
    configs={...},
    input_mappings={...},
    input_schema=[...],
    output_schema=[...]
)

# Kreiranje node-a iz system tool-a
node = WorkflowGraphNode.from_system_tool(
    tool_name='execute_code',
    name='CodeNode',
    configs={...},
    input_mappings={...},
    input_schema=[...],
    output_schema=[...]
)
```

### 3.3 Primer Workflow Grafa (iz postojećeg agenta)

```json
{
  "nodes": [
    {
      "name": "Transkribuj Audio iz OneDrive",
      "function_name": "transcribe_onedrive_audio",
      "source_code": "def transcribe_onedrive_audio():\n    from abacusai import AgentResponse, ApiClient\n    client = ApiClient()\n    # ... kod funkcije ...\n    return AgentResponse(\n        rezultat=\"...\",\n        transkripcije=[...]\n    )"
    }
  ],
  "edges": [],
  "primary_start_node": "Transkribuj Audio iz OneDrive",
  "specification_type": "data_flow"
}
```

---

## 4. Autonomni Agent Operacije

### 4.1 Pokretanje Autonomnog Agenta

```python
def start_autonomous_agent(
    deployment_token: str,
    deployment_id: str,
    arguments: List = None,
    keyword_arguments: dict = None,
    save_conversations: bool = True
) -> (str, ID)
```

### 4.2 Pauziranje Autonomnog Agenta

```python
def pause_autonomous_agent(
    deployment_token: str,
    deployment_id: str,
    deployment_conversation_id: str
) -> (str, ID)
```

### 4.3 Izvršavanje Conversation Agenta

```python
def execute_conversation_agent(
    deployment_token: str,
    deployment_id: str,
    arguments: List = None,
    keyword_arguments: dict = None,
    deployment_conversation_id: str = None,
    external_session_id: str = None,
    regenerate: bool = False,
    doc_infos: List = None,
    agent_workflow_node_id: str = None
) -> (str, ID)

# Streaming verzija
def execute_conversation_agent_streaming(...)
```

---

## 5. Context Metode za Perzistentnu Memoriju

### 5.1 Chat History

```python
# Dobijanje istorije chata
chat_history = client.get_agent_context_chat_history()
# Vraća: List[AgentChatMessage]

# Postavljanje istorije chata
client.set_agent_context_chat_history(chat_history)

# Dobijanje istorije formatiranog za LLM
conversation = client.get_agent_context_chat_history_for_llm()
# Vraća: AgentConversation
```

### 5.2 Conversation ID

```python
# Dobijanje conversation ID-a
conversation_id = client.get_agent_context_conversation_id()

# Postavljanje conversation ID-a
client.set_agent_context_conversation_id(conversation_id)
```

### 5.3 Document Info

```python
# Dobijanje doc info-a
doc_infos = client.get_agent_context_doc_infos()
doc_ids = client.get_agent_context_doc_ids()

# Postavljanje
client.set_agent_context_doc_infos(doc_infos)
client.set_agent_context_doc_ids(doc_ids)
```

### 5.4 External Session

```python
# Za multi-channel sesije
external_session_id = client.get_agent_context_external_session_id()
client.set_agent_context_external_session_id(external_session_id)
```

### 5.5 User Info

```python
user_info = client.get_agent_context_user_info()
```

### 5.6 Čišćenje Konteksta

```python
client.clear_agent_context()
```

---

## 6. AgentResponse i AgentChatMessage

### 6.1 AgentResponse

```python
from abacusai import AgentResponse

# Koristi se za vraćanje odgovora iz workflow node-a
return AgentResponse(
    rezultat="Uspešno završeno",      # Glavni rezultat
    transkripcije=[...],               # Dodatni podaci
    status="success",                  # Status
    # ... bilo koji kwargs
)
```

### 6.2 AgentChatMessage

```python
from abacusai import AgentChatMessage

# Struktura poruke u chatu
message = AgentChatMessage(
    client=client,
    role="user",           # "user" ili "assistant"
    text="Poruka",
    docIds=[...],          # ID-evi dokumenata
    keywordArguments={...},
    segments=[...],
    streamedData=None,
    streamedSectionData=None,
    agentWorkflowNodeId=None
)
```

---

## 7. Deployment Operacije

### 7.1 Kreiranje Deploymenta

```python
deployment = client.create_deployment(
    model_id=agent_id,
    name="Meta-Bot Deployment",
    description="Centralni agent za komunikaciju"
)
```

### 7.2 Kreiranje Deployment Tokena

```python
token = client.create_deployment_token(
    project_id=project_id,
    name="API Token"
)
```

### 7.3 Kreiranje Conversation-a

```python
conversation = client.create_deployment_conversation(
    deployment_id=deployment_id
)
```

### 7.4 Dobijanje Conversation-a

```python
conversation = client.get_deployment_conversation(
    deployment_conversation_id=conversation_id
)
```

---

## 8. OpenClaw Konfiguracija (SOUL.md)

### 8.1 Struktura SOUL.md Fajla

```markdown
# Core Truths
- Be genuinely helpful, not performatively helpful
- Have opinions and preferences
- Be resourceful before asking
- Earn trust through competence
- Remember you're a guest with access to user's data

# Boundaries
- Private things stay private
- When in doubt, ask before acting externally
- Never send half-baked replies
- You're not the user's voice

# Vibe
Concise when needed, thorough when it matters.
Not a corporate drone. Not a sycophant. Just good.

# Continuity
Each session, you wake up fresh. Memory files are your memory.
Read them. Update them. They're how you persist.
```

### 8.2 Povezani Fajlovi

| Fajl | Namena |
|------|--------|
| `SOUL.md` | Identitet i ličnost agenta |
| `STYLE.md` | Kako agent komunicira |
| `SKILL.md` | Operativni modovi |
| `MEMORY.md` | Sesijska memorija |
| `AGENTS.md` | Operativna pravila |
| `USER.md` | Profil korisnika |
| `TOOLS.md` | Dostupni alati |

---

## 9. Lobster Workflow Engine

Lobster je OpenClaw-native workflow shell za kreiranje typed, local-first, JSON-based pipeline-a.

### 9.1 Struktura .lobster Fajla

```yaml
name: my-workflow
args:
  input_file:
    default: "data.json"
steps:
  - id: fetch
    run: curl -s https://api.example.com/data
  
  - id: process
    pipeline: llm.invoke
    stdin: $fetch.stdout
    
  - id: approve
    approval: required
    
  - id: save
    run: echo "$process.json" > output.json
    when: $approve.approved
```

### 9.2 Ključni Koncepti

- **Typed Pipelines** - JSON-first data flow
- **Approval Gates** - Pauziranje za ljudsku verifikaciju
- **Resumable State** - Nastavak prekinutih workflow-a
- **LLM Integration** - `llm.invoke` za model-backed taskove

---

## 10. Multi-Channel Konfiguracija

### 10.1 WhatsApp

```yaml
whatsapp:
  selfChatMode: true
  dmPolicy: allowlist
  allowFrom:
    - "+381641234567"
  groupPolicy: disabled
  requireMention: true
```

### 10.2 Telegram

```yaml
telegram:
  botToken: "123456789:ABCdefGHIjklMNOpqrstUVwxyz"
  dmPolicy: allowlist
  allowFrom:
    - 123456789  # Telegram user ID
  groups:
    - id: -1001234567890
      requireMention: true
```

### 10.3 Slack

```yaml
slack:
  mode: socket  # ili http
  appToken: "xapp-..."
  botToken: "xoxb-..."
  channelPolicy: allowlist
  requireMention: true
```

---

## 11. Postojeći Agenti Korisnika

### Pronađeni projekti sa agentima:

| Projekat | Agent | Agent ID | Tip |
|----------|-------|----------|-----|
| _z_transcription | Audio Transcription | 598617dce | DEFAULT |
| Transcription Workflow V2 | Transcription Workflow V2 | 14a2efe438 | DEFAULT |
| Lektor Srpski Auto Monitor | Cloud Audio Transcription | - | DEFAULT |
| context_loader_test | context_loader_test | - | DEFAULT |
| Transcription Workflow V1 | 1_Transcribe | - | DEFAULT |

### Primer Konfiguracije Postojećeg Agenta:

```json
{
  "DESCRIPTION": "Monitoruje OneDrive folder _recording i automatski transkribuje audio fajlove na srpski jezik.",
  "AGENT_INTERFACE": "DEFAULT",
  "AGENT_CONNECTORS": {},
  "_llm_node_model_instance_ids": []
}
```

---

## 12. Preporuke za Meta-Bot Implementaciju

### 12.1 Arhitektura

```
┌─────────────────────────────────────────────────────────┐
│                    META-BOT AGENT                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │
│  │   SOUL.md   │  │  MEMORY.md  │  │   TOOLS.md      │  │
│  │  (Identitet)│  │  (Memorija) │  │   (Alati)       │  │
│  └─────────────┘  └─────────────┘  └─────────────────┘  │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │              WORKFLOW GRAPH                      │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────────┐   │    │
│  │  │ Channel  │→ │ Router   │→ │ DeepAgent    │   │    │
│  │  │ Handler  │  │ (Intent) │  │ Delegator    │   │    │
│  │  └──────────┘  └──────────┘  └──────────────┘   │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │              CHANNELS                            │    │
│  │  ┌─────────┐  ┌──────────┐  ┌───────────────┐   │    │
│  │  │WhatsApp │  │ Telegram │  │    Slack      │   │    │
│  │  └─────────┘  └──────────┘  └───────────────┘   │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

### 12.2 Primer Koda za Meta-Bot

```python
from abacusai import (
    ApiClient, 
    AgentResponse, 
    WorkflowGraph, 
    WorkflowGraphNode,
    AgentInterface
)

def meta_bot_handler():
    """
    Centralni handler za Meta-Bot koji delegira zadatke DeepAgent-u.
    """
    client = ApiClient()
    
    # Dobij kontekst
    chat_history = client.get_agent_context_chat_history()
    user_info = client.get_agent_context_user_info()
    conversation_id = client.get_agent_context_conversation_id()
    
    # Poslednja poruka korisnika
    last_message = chat_history[-1].text if chat_history else ""
    
    # Učitaj perzistentnu memoriju
    memory = load_memory_from_file()
    
    # Analiziraj intent
    intent = analyze_intent(last_message)
    
    if intent == "complex_task":
        # Delegiraj DeepAgent-u
        response = client.get_deep_agent_response(
            messages=[{"role": "user", "content": last_message}]
        )
        result = response.content
    else:
        # Jednostavan odgovor
        result = generate_simple_response(last_message, memory)
    
    # Ažuriraj memoriju
    update_memory(memory, last_message, result)
    
    return AgentResponse(
        response=result,
        memory_updated=True,
        intent=intent
    )

def analyze_intent(message: str) -> str:
    """Analiza intenta poruke."""
    # LLM-based intent classification
    pass

def load_memory_from_file() -> dict:
    """Učitavanje perzistentne memorije."""
    # Čitaj iz MEMORY.md ili SQLite
    pass

def update_memory(memory: dict, message: str, response: str):
    """Ažuriranje perzistentne memorije."""
    # Piši u MEMORY.md ili SQLite
    pass
```

### 12.3 Workflow Graph za Meta-Bot

```python
from abacusai import WorkflowGraph, WorkflowGraphNode

# Definicija workflow grafa
meta_bot_workflow = WorkflowGraph(
    nodes=[
        WorkflowGraphNode(
            name="Meta Bot Handler",
            function_name="meta_bot_handler",
            source_code="""
def meta_bot_handler():
    from abacusai import ApiClient, AgentResponse
    client = ApiClient()
    
    # Glavni kod handlera...
    
    return AgentResponse(response="...")
"""
        )
    ],
    edges=[],
    primary_start_node="Meta Bot Handler",
    specification_type="data_flow"
)
```

### 12.4 Koraci za Implementaciju

1. **Kreiranje projekta**
   ```python
   project = client.create_project(
       name="Meta-Bot Project",
       use_case="AI_AGENT"
   )
   ```

2. **Kreiranje agenta**
   ```python
   agent = client.create_agent(
       project_id=project.project_id,
       name="Meta-Bot",
       description="Centralni agent za multi-channel komunikaciju",
       workflow_graph=meta_bot_workflow,
       agent_interface=AgentInterface.AUTONOMOUS,
       user_level_connectors={
           ApplicationConnectorType.SLACK: [],
           ApplicationConnectorType.ONEDRIVE: []
       }
   )
   ```

3. **Deployment**
   ```python
   deployment = client.create_deployment(
       model_id=agent.agent_id,
       name="Meta-Bot Production"
   )
   ```

4. **Konfiguracija kanala** (kroz Claw UI)

5. **Testiranje**
   ```python
   response = client.execute_conversation_agent(
       deployment_token=token,
       deployment_id=deployment.deployment_id,
       keyword_arguments={"message": "Hello, Meta-Bot!"}
   )
   ```

---

## 13. Zaključak i Sledeći Koraci

### Ključni Nalazi:

1. **SDK je kompletan** - Sve potrebne metode postoje za kreiranje, deploy i upravljanje agentima
2. **WorkflowGraph je fleksibilan** - Možemo definisati custom workflow-e sa Python kodom
3. **Perzistentna memorija** - Dostupna kroz context metode i fajl sistem
4. **Multi-channel** - Podržani WhatsApp, Telegram, Slack
5. **DeepAgent integracija** - Moguća kroz `get_deep_agent_response`

### Preporučeni Sledeći Koraci:

1. ✅ Definisati SOUL.md za Meta-Bot ličnost
2. ✅ Implementirati osnovni workflow handler
3. ✅ Kreirati sistem za perzistentnu memoriju
4. ✅ Integrisati sa DeepAgent-om za kompleksne zadatke
5. ✅ Konfigurisati multi-channel gateway
6. ✅ Testirati end-to-end flow

---

*Dokument kreiran: 1. April 2026.*
*Verzija: 1.0*
