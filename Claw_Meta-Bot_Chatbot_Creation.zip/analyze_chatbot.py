import abacusai
import json

client = abacusai.ApiClient()

# IDs
document_retriever_id = "1088ad145a"
deployment_id = "1127df3f3a"

print("=" * 60)
print("1. DOCUMENT RETRIEVER ANALIZA")
print("=" * 60)

# Describe Document Retriever
try:
    dr = client.describe_document_retriever(document_retriever_id)
    print("\n📚 Document Retriever Info:")
    print(json.dumps(dr.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"describe_document_retriever error: {e}")

# List documents
try:
    docs = client.list_document_retriever_documents(document_retriever_id)
    print("\n📄 Documents in Retriever:")
    if hasattr(docs, '__iter__'):
        for i, doc in enumerate(docs):
            if hasattr(doc, 'to_dict'):
                print(f"\n  Document {i+1}:")
                print(json.dumps(doc.to_dict(), indent=4, default=str))
            else:
                print(f"  {i+1}. {doc}")
    else:
        print(docs)
except Exception as e:
    print(f"list_document_retriever_documents error: {e}")

print("\n" + "=" * 60)
print("2. DEPLOYMENT/CHATBOT ANALIZA")
print("=" * 60)

# Describe deployment
try:
    dep = client.describe_deployment(deployment_id)
    print("\n🤖 Deployment Info:")
    print(json.dumps(dep.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"describe_deployment error: {e}")

# Get deployment
try:
    dep2 = client.get_deployment(deployment_id)
    print("\n🔧 Get Deployment:")
    print(json.dumps(dep2.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"get_deployment error: {e}")

# Try to get agent info
try:
    agent = client.describe_agent(deployment_id)
    print("\n🧠 Agent Info:")
    print(json.dumps(agent.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"describe_agent error: {e}")

