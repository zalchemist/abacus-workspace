import abacusai
import json

client = abacusai.ApiClient()

# Try describe dataset
dataset_id = "115d6d8e36"

try:
    ds = client.describe_dataset(dataset_id)
    print("📦 Dataset Info:")
    print(json.dumps(ds.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"Error: {e}")

# List dataset versions 
try:
    versions = client.list_dataset_versions(dataset_id)
    print("\n📋 Dataset Versions:")
    for v in versions[:3]:
        print(json.dumps(v.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"Error: {e}")

