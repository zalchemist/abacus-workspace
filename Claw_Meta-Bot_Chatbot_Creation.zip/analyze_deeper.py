import abacusai
import json

client = abacusai.ApiClient()

feature_group_id = "15ff32b2b0"
document_retriever_id = "1088ad145a"
model_id = "8a363de6c"

print("=" * 60)
print("3. FEATURE GROUP (Knowledge Base) ANALIZA")
print("=" * 60)

# Describe Feature Group
try:
    fg = client.describe_feature_group(feature_group_id)
    print("\n📊 Feature Group Info:")
    fg_dict = fg.to_dict()
    print(json.dumps(fg_dict, indent=2, default=str))
except Exception as e:
    print(f"describe_feature_group error: {e}")

# Get Feature Group schema
try:
    schema = client.get_feature_group_schema(feature_group_id)
    print("\n📋 Feature Group Schema:")
    print(json.dumps([s.to_dict() for s in schema], indent=2, default=str))
except Exception as e:
    print(f"get_feature_group_schema error: {e}")

# Preview data in feature group
print("\n" + "=" * 60)
print("4. PREGLED DOKUMENATA U KNOWLEDGE BASE")
print("=" * 60)

try:
    preview = client.execute_feature_group_sql(
        sql=f"SELECT * FROM {feature_group_id} LIMIT 50"
    )
    print("\n📄 Documents Preview:")
    if hasattr(preview, 'rows'):
        print(f"   Columns: {preview.columns}")
        print(f"   Total rows returned: {len(preview.rows)}")
        for i, row in enumerate(preview.rows[:15]):  # Show first 15
            print(f"\n   --- Document {i+1} ---")
            for j, col in enumerate(preview.columns):
                val = str(row[j])[:200] if row[j] else "NULL"
                print(f"   {col}: {val}")
    else:
        print(preview)
except Exception as e:
    print(f"SQL preview error: {e}")

# Model info
print("\n" + "=" * 60)
print("5. MODEL/AGENT KONFIGURACIJA")
print("=" * 60)

try:
    model = client.describe_model(model_id)
    print("\n🧠 Model Info:")
    print(json.dumps(model.to_dict(), indent=2, default=str))
except Exception as e:
    print(f"describe_model error: {e}")

