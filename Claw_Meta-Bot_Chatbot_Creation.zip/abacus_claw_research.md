# Abacus Claw - Detaljan Istraživački Izveštaj

**Datum:** 1. april 2026.  
**Pripremio:** DeepAgent

---

## Sadržaj
1. [Šta je Abacus Claw?](#1-šta-je-abacus-claw)
2. [Glavne mogućnosti](#2-glavne-mogućnosti)
3. [Multiagent struktura](#3-multiagent-struktura)
4. [Perzistentna memorija](#4-perzistentna-memorija)
5. [Workflow mogućnosti](#5-workflow-mogućnosti)
6. [Abacus SDK - API metode](#6-abacus-sdk---api-metode)
7. [Integracija sa DeepAgent-om](#7-integracija-sa-deepagent-om)
8. [Preporuke za upotrebu](#8-preporuke-za-upotrebu)

---

## 1. Šta je Abacus Claw?

**Abacus Claw** je hosted, managed verzija **OpenClaw** - open-source platforme za perzistentne AI agente. Omogućava deployment AI agenata koji rade 24/7 u cloud-u sa sledećim karakteristikama:

| Karakteristika | Opis |
|----------------|------|
| **Tip** | Managed AI agent platforma |
| **Baza** | OpenClaw (open-source) |
| **Infrastruktura** | Abacus.AI cloud |
| **Pretplata** | Pro ($10/mesec, $7 prvi mesec) |
| **Krediti** | 25,000 mesečno uključeno |

### Arhitektura
```
┌─────────────────────────────────────────────────────────┐
│                    ABACUS CLAW                          │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │
│  │  Persistent │  │   Cloud     │  │  Multi-Channel  │  │
│  │   Memory    │  │  Computer   │  │    Gateway      │  │
│  └─────────────┘  └─────────────┘  └─────────────────┘  │
│           ▲              ▲                ▲             │
│           │              │                │             │
│           ▼              ▼                ▼             │
│  ┌─────────────────────────────────────────────────┐    │
│  │            AI Agent (OpenClaw)                  │    │
│  │  • LLM Processing  • Tool Execution            │    │
│  │  • Workflow Engine • Session Management        │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
           │              │              │
           ▼              ▼              ▼
      WhatsApp       Telegram         Slack
```

---

## 2. Glavne mogućnosti

### 2.1 Perzistentna memorija
- Pamti kontekst između sesija i kanala
- Strukturirani fajlovi u cloud computer-u
- Automatsko učitavanje pre i ažuriranje posle odgovora

### 2.2 Perzistentna operacija (24/7)
- Agent radi kontinuirano u cloud-u
- Reaguje čak i kad je korisnik offline
- Real-time monitoring eksternih servisa

### 2.3 Cron Jobs
- Zakazani zadaci (dnevni briefings, nedeljni reporti)
- Periodični data pulls
- Automatizovani workflow-i

### 2.4 Multi-Channel pristup

| Kanal | Mogućnosti |
|-------|-----------|
| **WhatsApp** | Self-chat mode, DM policy, group policy (JIDs) |
| **Telegram** | Bot token, privacy mode, user ID allowlist |
| **Slack** | Socket mode, bot token, channel policies |

### 2.5 Tool integracije
- **Productivity:** Gmail, Google Calendar, Google Drive, Notion
- **Development:** GitHub, Slack
- **Custom:** OAuth i API key integracije

### 2.6 Cloud Computer
- Pun Linux environment
- Terminal pristup
- Browser za web automation
- Perzistentno skladištenje fajlova

---

## 3. Multiagent struktura

### 3.1 Arhitektura izolacije

Svaki agent u OpenClaw ima tri fundamentalne komponente:

```
┌─────────────────────────────────────────┐
│              AGENT IZOLACIJA            │
├─────────────────────────────────────────┤
│  1. Workspace (agentDir)                │
│     • Konfiguracija                     │
│     • Memory storage                    │
│     • Skill definicije                  │
├─────────────────────────────────────────┤
│  2. Session Store                       │
│     • Conversation history              │
│     • Session state                     │
│     • Kompletna izolacija po agentu     │
├─────────────────────────────────────────┤
│  3. Authentication Context              │
│     • API keys po agentu                │
│     • OAuth tokens                      │
│     • Service credentials               │
└─────────────────────────────────────────┘
```

### 3.2 Agent Bindings (Routing)

```yaml
# Primer konfiguracije routinga
agentBindings:
  - channel: discord
    accountId: "123456789"
    agentId: "support-agent"
  - channel: telegram
    botUsername: "@MyBot"
    agentId: "telegram-agent"
  - channel: whatsapp
    phoneNumber: "+381..."
    agentId: "whatsapp-agent"
```

### 3.3 Orchestration Patterns

#### Pattern 1: Coordinator-Specialist (Preporučen)
```
┌────────────────────┐
│   COORDINATOR      │ ← Prima sve zahteve
│   (Claude Opus)    │
└─────────┬──────────┘
          │ Delegira
    ┌─────┴─────┐
    ▼           ▼
┌────────┐ ┌────────┐
│ SPEC 1 │ │ SPEC 2 │  ← Stateless specijalisti
│(Email) │ │(GitHub)│
└────────┘ └────────┘
```

#### Pattern 2: Dream Team
- Više specijalizovanih agenata
- Svaki "poseduje" specifičan domen
- Kompleksno, ali maksimalna specijalizacija

#### Pattern 3: Hierarchical (Opus + Codex Workers)
- Moćan orchestrator razbija zadatke
- Jeftiniji/brži modeli izvršavaju
- Orchestrator sintetiše rezultate

### 3.4 Lobster Workflow Engine

OpenClaw koristi **Lobster** - typed, local-first pipeline runtime:

```yaml
# Primer Lobster workflow-a
name: code-review-pipeline
steps:
  - id: analyze
    tool: llm-task
    params:
      prompt: "Analiziraj ovaj kod..."
      
  - id: review
    tool: agent-send
    params:
      agentId: "reviewer-agent"
      message: "{{analyze.output}}"
      
  - id: loop-check
    type: condition
    if: "{{review.needsRevision}}"
    then: goto analyze
```

**Mogućnosti Lobster-a:**
- Determinističko izvršavanje
- Approval gates
- Resume tokens
- Sub-lobster steps (nested workflows)
- Loop podrška

---

## 4. Perzistentna memorija

### 4.1 Kako funkcioniše

```
┌──────────────────────────────────────────────────────┐
│                 MEMORY LIFECYCLE                      │
├──────────────────────────────────────────────────────┤
│                                                       │
│   1. LOAD: Agent čita memory fajlove pre odgovora    │
│      └─> preferences.json, context.md, tasks.json    │
│                                                       │
│   2. PROCESS: LLM koristi kontekst za odgovor        │
│      └─> Razume prethodne interakcije                │
│                                                       │
│   3. UPDATE: Agent ažurira memory posle odgovora     │
│      └─> Dodaje nove informacije, ažurira stanje     │
│                                                       │
└──────────────────────────────────────────────────────┘
```

### 4.2 Tipovi memorije

| Tip | Skladištenje | Upotreba |
|-----|-------------|----------|
| **Preferences** | JSON fajl | Korisničke preferencije, podešavanja |
| **Conversation History** | Session store | Prethodne poruke i kontekst |
| **Task Tracking** | Structured files | Aktivni zadaci, deadlines |
| **Knowledge Base** | Markdown/JSON | Akumulirano znanje |

### 4.3 Cross-Channel memorija

Ključna prednost: **ista memorija** važi za sve kanale:
- Informacija podeljena na WhatsApp-u → dostupna na Telegram-u
- Task kreiran na Slack-u → reminder na WhatsApp-u

---

## 5. Workflow mogućnosti

### 5.1 Cron Job primeri

```python
# Dnevni email digest - 8:00 AM
"0 8 * * *": "Sumiraj nepročitane mejlove i pošalji na Slack"

# Nedeljni trending topics - Petak 17:00
"0 17 * * 5": "Analiziraj Hacker News i napravi report"

# Svaki sat - monitoring
"0 * * * *": "Proveri GitHub issues za kritične bagove"
```

### 5.2 Event-Driven Workflows

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   TRIGGER   │────▶│   PROCESS   │────▶│   ACTION    │
│  (Event)    │     │  (AI Agent) │     │  (Output)   │
└─────────────┘     └─────────────┘     └─────────────┘

Primeri:
• GitHub PR → Code Review → Comment
• Email od VIP → Analiza → Slack Alert
• Keyword u Slack → Research → Report
```

### 5.3 Multi-Step Automation

```
Primer: Content Repurposing Pipeline

1. INPUT: Blog post (Notion/Google Doc)
      ↓
2. TRANSFORM: AI prilagođava za platformu
      ↓
3. OUTPUT: 
   • Twitter thread → X
   • LinkedIn post → LinkedIn
   • Short summary → Slack
   • Archive → Notion database
```

---

## 6. Abacus SDK - API metode

### 6.1 Agent CRUD operacije

```python
import abacusai
client = abacusai.ApiClient()

# KREIRANJE AGENTA
agent = client.create_agent(
    project_id="project_123",
    name="My Claw Agent",
    memory=4096,  # MB
    description="Personal assistant agent",
    workflow_graph=my_workflow,
    agent_interface=AgentInterface.DEFAULT,
    package_requirements=["requests", "pandas"],
    org_level_connectors=["gmail", "github"],
    user_level_connectors={
        ApplicationConnectorType.SLACK: ["workspace_id"]
    }
)

# LISTANJE AGENATA
agents = client.list_agents(project_id="project_123")

# OPISIVANJE AGENTA
agent_details = client.describe_agent(agent_id="agent_456")

# AŽURIRANJE AGENTA
updated = client.update_agent(
    model_id="agent_456",
    description="Updated description",
    workflow_graph=new_workflow
)
```

### 6.2 Workflow Graph operacije

```python
# VALIDACIJA WORKFLOW-A
validation = client.validate_workflow_graph(
    workflow_graph=my_graph,
    agent_interface=AgentInterface.DEFAULT
)

# IZVRŠAVANJE WORKFLOW-A (test)
result = client.run_workflow_graph(
    workflow_graph=my_graph,
    sample_user_inputs={"query": "test input"}
)

# EKSTRAKCIJA INFORMACIJA
info = client.extract_agent_workflow_information(
    workflow_graph=my_graph
)
```

### 6.3 Conversation i Chat operacije

```python
# KREIRANJE KONVERZACIJE
conversation = client.create_deployment_conversation(
    deployment_id="deploy_789",
    name="Support Session"
)

# DOBIJANJE ODGOVORA
response = client.get_conversation_response(
    deployment_id="deploy_789",
    message="Kako mogu pomoći?",
    deployment_token="token_abc",
    deployment_conversation_id=conversation.id,
    temperature=0.7
)

# IZVRŠAVANJE CONVERSATION AGENTA
result = client.execute_conversation_agent(
    deployment_token="token",
    deployment_id="deploy_789",
    keyword_arguments={"query": "..."},
    deployment_conversation_id=conversation.id
)

# DOBIJANJE ISTORIJE ZA LLM
history = client.construct_agent_conversation_messages_for_llm(
    deployment_conversation_id=conversation.id,
    include_document_contents=True
)
```

### 6.4 DeepAgent specifične metode

```python
# DEEPAGENT ODGOVOR (direktan API)
response = client.get_deep_agent_response(
    message="Napravi mi Python skriptu za...",
    deployment_conversation_id="conv_123"  # opciono
)

# CHATLLM COMPUTER STREAMING (iz agent konteksta)
# Ovo omogućava Claw agentu da koristi cloud computer
client.execute_chatllm_computer_streaming(
    computer_id="computer_xyz",
    prompt="Otvori browser i idi na google.com",
    is_transient=False
)
```

### 6.5 Webhook i Automation

```python
# KREIRANJE WEBHOOK-A
webhook = client.create_deployment_webhook(
    deployment_id="deploy_789",
    endpoint="https://myserver.com/webhook",
    webhook_event_type="conversation_complete",
    payload_template={"event": "{{event}}", "data": "{{data}}"}
)

# REFRESH POLICY (Cron)
policy = client.create_refresh_policy(
    name="Daily Agent Refresh",
    cron="0 8 * * *",  # Svaki dan u 8:00 UTC
    refresh_type="AGENT",
    deployment_ids=["deploy_789"]
)
```

### 6.6 Context i Memory (iz Agent koda)

```python
# Ove metode se koriste UNUTAR agent execute funkcije

# Dobijanje chat istorije
history = client.get_agent_context_chat_history()

# Istorija formatirana za LLM
llm_history = client.get_agent_context_chat_history_for_llm()

# Čišćenje konteksta
client.clear_agent_context()

# Export konverzacije
export = client.export_deployment_conversation(
    deployment_conversation_id="conv_123"
)
```

---

## 7. Integracija sa DeepAgent-om

### 7.1 Trenutni status integracije

```
┌─────────────────────────────────────────────────────────┐
│               INTEGRACIJA DEEPAGENT ↔ CLAW              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  DeepAgent                         Abacus Claw          │
│  ┌─────────────┐                   ┌─────────────┐      │
│  │ Session-    │                   │ Persistent  │      │
│  │ based       │    Indirektna     │ 24/7        │      │
│  │ execution   │◄──integracija ───►│ agent       │      │
│  │             │   (API calls)     │             │      │
│  └─────────────┘                   └─────────────┘      │
│                                                         │
│  Zajedničko:                                            │
│  • Ista Abacus.AI infrastruktura                        │
│  • Isti API client                                      │
│  • Deljeni connectors (Gmail, GitHub, Slack...)         │
│  • Isti kredit sistem                                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 7.2 Može li DeepAgent pozivati Claw agente?

**DA, indirektno** kroz:

```python
# Metod 1: Preko deployed Claw agent API
result = client.execute_conversation_agent(
    deployment_token="claw_agent_token",
    deployment_id="claw_deployment_id",
    keyword_arguments={"message": "Izvrši zadatak X"}
)

# Metod 2: Preko conversation response
response = client.get_conversation_response(
    deployment_id="claw_deployment_id",
    message="Pokreni workflow Y",
    deployment_token="token"
)
```

### 7.3 Može li Claw pozivati DeepAgent?

**DA**, korišćenjem:

```python
# Iz Claw agent koda
response = client.get_deep_agent_response(
    message="Napravi kompleksnu analizu podataka...",
    deployment_conversation_id=None  # Nova konverzacija
)

# Ili kroz ChatLLM Computer
client.execute_chatllm_computer_streaming(
    computer_id="deepagent_computer",
    prompt="Koristi DeepAgent za kreiranje aplikacije..."
)
```

### 7.4 Razmena informacija

| Metod | Opis |
|-------|------|
| **Shared Connectors** | Oba koriste iste OAuth konekcije |
| **API Calls** | Direktni pozivi između deployed agenata |
| **Webhooks** | Event-driven komunikacija |
| **Shared Storage** | Kroz Feature Groups ili eksterno |
| **Conversation Export** | Transfer konteksta između agenata |

---

## 8. Preporuke za upotrebu

### 8.1 Meta-Bot arhitektura

```
┌─────────────────────────────────────────────────────────┐
│                    META-BOT SETUP                       │
├─────────────────────────────────────────────────────────┤
│                                                         │
│                 ┌─────────────────┐                     │
│                 │   META-AGENT    │                     │
│                 │   (Claw - 24/7) │                     │
│                 └────────┬────────┘                     │
│                          │                              │
│         ┌────────────────┼────────────────┐             │
│         │                │                │             │
│         ▼                ▼                ▼             │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐         │
│   │ Research │    │ Content  │    │ DevOps   │         │
│   │ Workflow │    │ Workflow │    │ Workflow │         │
│   │(DeepAgt) │    │(Claw)    │    │(Claw)    │         │
│   └──────────┘    └──────────┘    └──────────┘         │
│                                                         │
│  Trigger: WhatsApp/Telegram komanda                     │
│  Meta-agent odlučuje koji workflow pokrenuti            │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Preporučena implementacija:**

```python
# Meta-agent workflow (pojednostavljen)
def meta_agent_execute(client, message, context):
    # 1. Klasifikuj zadatak
    task_type = classify_task(message)
    
    # 2. Delegiraj odgovarajućem workflow-u
    if task_type == "research":
        return client.get_deep_agent_response(message)
    elif task_type == "content":
        return execute_content_workflow(message)
    elif task_type == "devops":
        return execute_devops_workflow(message)
    else:
        return handle_general_query(message)
```

### 8.2 Workflow za parsiranje

```yaml
# parsing-workflow.lobster
name: document-parsing-pipeline
description: Parsira dokumente i ekstraktuje strukturirane podatke

steps:
  - id: receive
    type: input
    schema:
      document_url: string
      extract_fields: array
      
  - id: fetch
    tool: web-fetch
    params:
      url: "{{receive.document_url}}"
      
  - id: extract
    tool: llm-task
    params:
      prompt: |
        Ekstraktuj sledeća polja iz dokumenta:
        {{receive.extract_fields}}
        
        Dokument:
        {{fetch.content}}
      response_type: json
      
  - id: validate
    tool: code-exec
    params:
      code: |
        import json
        data = json.loads("{{extract.output}}")
        # Validacija
        return {"valid": True, "data": data}
        
  - id: store
    tool: notion-create
    condition: "{{validate.valid}}"
    params:
      database_id: "notion_db_id"
      properties: "{{validate.data}}"
```

### 8.3 Konkretne preporuke

#### Za Meta-Bot:
1. **Koristi Claw kao persistentni router** - prima sve zahteve
2. **Delegiraj kompleksne zadatke DeepAgent-u** - za kreiranje koda, aplikacija
3. **Koristi Lobster za determinističke tokove** - gde je ponovljivost bitna

#### Za Workflow parsiranje:
1. **Definiši jasne inpute i outpute** - schema validacija
2. **Koristi `llm-task` za ekstrakciju** - fleksibilno parsiranje
3. **Implementiraj error handling** - retry logika u Lobster-u

#### Za memoriju:
1. **Strukturiraj memory fajlove** - JSON za strukturirane podatke
2. **Implementiraj memory pruning** - izbegni preopterećenje
3. **Koristi cross-channel sync** - konzistentnost između kanala

### 8.4 Primer kompletnog setup-a

```python
import abacusai

client = abacusai.ApiClient()

# 1. Kreiraj meta-agent projekat
project = client.create_project(
    name="Meta-Bot System",
    use_case="CHAT_BOT"
)

# 2. Definiši workflow graph za meta-agent
meta_workflow = {
    "nodes": [
        {"id": "input", "type": "input"},
        {"id": "classifier", "type": "llm", "model": "claude-3-opus"},
        {"id": "router", "type": "conditional"},
        {"id": "research_branch", "type": "external_agent"},
        {"id": "content_branch", "type": "internal_workflow"},
        {"id": "output", "type": "output"}
    ],
    "edges": [...]
}

# 3. Kreiraj agenta
agent = client.create_agent(
    project_id=project.project_id,
    name="Meta-Bot",
    workflow_graph=meta_workflow,
    org_level_connectors=["SLACK", "GMAILUSER", "GITHUBUSER"]
)

# 4. Deploy
deployment = client.create_deployment(
    model_id=agent.model_id,
    name="Meta-Bot Production"
)

# 5. Konfiguriši Claw kanale (kroz Claw UI)
# - WhatsApp self-chat
# - Telegram bot
# - Slack workspace
```

---

## Zaključak

**Abacus Claw** je moćna platforma za perzistentne AI agente koja odlično dopunjuje DeepAgent:

| Aspekt | Claw | DeepAgent |
|--------|------|-----------|
| **Trajanje** | 24/7 persistent | Session-based |
| **Kanali** | WhatsApp, Telegram, Slack | Web UI |
| **Memory** | Cross-session | In-session |
| **Use case** | Automation, monitoring | Complex tasks, app building |

**Preporučena strategija:**
1. Claw kao **persistentni frontend** - prima zahteve, pamti kontekst
2. DeepAgent kao **execution engine** - kompleksni zadaci
3. Lobster workflows za **determinističke procese**
4. Shared connectors za **seamless integraciju**

---

## Reference

1. [Abacus Claw dokumentacija](https://abacus.ai/help/chatllm-ai-super-assistant/abacus-claw)
2. [Claw.abacus.ai](https://claw.abacus.ai/)
3. [OpenClaw Multi-Agent Guide](https://docs.openclaw.ai/concepts/multi-agent)
4. [Abacus.AI Python SDK](https://pypi.org/project/abacusai/)
5. [OpenClaw Lobster Engine](https://dev.to/ggondim/how-i-built-a-deterministic-multi-agent-dev-pipeline-inside-openclaw)
