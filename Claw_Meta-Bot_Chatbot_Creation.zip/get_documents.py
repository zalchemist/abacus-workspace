import abacusai
import json

client = abacusai.ApiClient()

table_name = "abacus_knowledge_base_dataset_260331054042"

print("=" * 60)
print("DOKUMENTI U KNOWLEDGE BASE")
print("=" * 60)

# Try with table name
try:
    preview = client.execute_feature_group_sql(
        sql=f"SELECT doc_id, file_path, file_size_bytes, mime_type, page_count, token_count FROM {table_name}"
    )
    print(f"\n📄 Pronađeno {len(preview.rows)} dokumenata:\n")
    
    total_tokens = 0
    total_pages = 0
    total_size = 0
    
    for i, row in enumerate(preview.rows):
        doc_id, file_path, size, mime, pages, tokens = row
        print(f"{i+1}. {file_path}")
        print(f"   📁 Tip: {mime} | 📄 Strana: {pages} | 🔤 Tokena: {tokens} | 💾 {size/1024:.1f} KB")
        total_tokens += tokens or 0
        total_pages += pages or 0
        total_size += size or 0
    
    print("\n" + "-" * 60)
    print(f"📊 UKUPNO:")
    print(f"   Dokumenata: {len(preview.rows)}")
    print(f"   Stranica: {total_pages}")
    print(f"   Tokena: {total_tokens:,}")
    print(f"   Veličina: {total_size/1024:.1f} KB ({total_size/1024/1024:.2f} MB)")
    
except Exception as e:
    print(f"SQL error: {e}")

# Also get file descriptions
print("\n\n" + "=" * 60)
print("OPISI DOKUMENATA")
print("=" * 60)

try:
    desc_preview = client.execute_feature_group_sql(
        sql=f"SELECT file_path, file_description FROM {table_name}"
    )
    for row in desc_preview.rows:
        file_path, description = row
        if description:
            print(f"\n📄 {file_path}")
            print(f"   {description[:300]}...")
except Exception as e:
    print(f"Error: {e}")

